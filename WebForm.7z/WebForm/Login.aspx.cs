﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.Web.UI;

public partial class Page_System_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Loginbtn_Click(object sender, EventArgs e)
    {
        if (TextUser.Text.Trim() == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('The user name cannot be null!');", true);
            return;
        }
        else if (TextPassword.Text.Trim() == "")
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('The password cannot be null!');", true);
            return;
        }
        else
        {
            string connString = System.Configuration.ConfigurationManager.ConnectionStrings["BTSDB"].ConnectionString;
            OracleConnection conn = new OracleConnection(connString);

            conn.Open();

            string uid = TextUser.Text.Trim().ToUpper();
            string pwd = TextPassword.Text.Trim();
            string sql = "Select * from BTS.BTS_USER_ACCOUNT where Upper(USER_NAME)='" + uid + "'";

            using (OracleCommand cmd = new OracleCommand(sql, conn))
            {
                cmd.Parameters.Add(new OracleParameter("uid", OracleDbType.Varchar2)).Value = uid;
                cmd.Parameters.Add(new OracleParameter("pwd", OracleDbType.Varchar2)).Value = pwd;

                using (OracleDataAdapter adp = new OracleDataAdapter(cmd))
                {
                    DataTable ds = new DataTable();
                    adp.Fill(ds);
                    int rowCount = ds.Rows.Count;

                    if (rowCount == 0)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('The account does not exist!');", true);
                        return;
                    }
                    else
                    {
                        sql = "Select * from BTS.BTS_USER_ACCOUNT where Upper(USER_NAME)='" + uid + "' and PASSWORD='" + pwd + "'";
                        cmd.CommandText = sql;

                        DataTable ads = new DataTable();
                        adp.Fill(ads);
                        rowCount = ads.Rows.Count;

                        if (rowCount == 0)
                        {
                            ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('The password is incorrect. Please re-enter the password!');", true);
                            return;
                        }
                        else
                        {
                            Session["USERID"] = uid;
                            //Response.Redirect("~/Page/Main.aspx");
                            Response.Redirect("~/Page/Main.aspx");
                        }
                    }
                }
            }
            conn.Close();
        }
    }
}