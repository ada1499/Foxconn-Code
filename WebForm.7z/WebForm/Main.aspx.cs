﻿using System;
using System.Web.UI;

public partial class Page_Main : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string UserID = Session["USERID"] as string;
        if (UserID == null)
        {
            Response.Redirect("~/Page/System/Login.aspx");
            return;
        }
    }

    protected void ImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("~/Page/System/Login.aspx");
        return;
    }
}