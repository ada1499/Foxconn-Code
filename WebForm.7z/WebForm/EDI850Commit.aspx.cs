﻿using OfficeOpenXml;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Data;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using Wuqi.Webdiyer;

public partial class Page_EDI850Commit : System.Web.UI.Page
{
    private DataTable data;
    private DataTable uploadedData = new DataTable();
    private bool ShouldSkipRowDataBound = false;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check whether the user is logged in.
        string UserID = Session["USERID"] as string;
        if (UserID == null)
        {
            Response.Redirect("~/Page/System/Login.aspx");
            ShowErrorMessage("Login expired, please login again.");
            return;
        }

        // The page is bound to the GridView when it first loads.
        if (!IsPostBack)
        {
            ViewState["uploadData"] = null;
            BindGridView("", "", "", true);
        }
    }

    private void BindGridView(string p_site, string p_po, string p_partno, bool isSearch)
    {
        if (ViewState["uploadData"] != null)
        {
            data = ViewState["uploadData"] as DataTable;
            ShouldSkipRowDataBound = true;
        }
        else
        {
            data = ViewState["850DATA"] as DataTable;
        }

        if (data == null || isSearch == true)
        {
            string userID = Session["USERID"] as string;
            data = Get850Data(p_site, p_po, p_partno, userID);
            ViewState["850DATA"] = data;// Store in the ViewState and apply the policy.
        }
        // Create the PagedDataSource object and set its properties.
        PagedDataSource pds = new PagedDataSource();
        AspNetPager.RecordCount = data.Rows.Count;
        pds.DataSource = data.DefaultView;
        pds.CurrentPageIndex = AspNetPager.CurrentPageIndex - 1;
        pds.PageSize = AspNetPager.PageSize;
        pds.AllowPaging = true;
        try
        {
            // Set the PagedDataSource object as the data source for the GridView and bind the data.
            GridView.DataSource = pds;
            GridView.DataBind();
        }
        catch(Exception ex)
        {
            ShowErrorMessage("An error occurred while binding the GridView:" + ex.Message);
        }
    }

    public DataTable Get850Data(string p_site, string p_po, string p_partno, string userID)
    {
        DataTable result = new DataTable();
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["BTSDB"].ConnectionString;

        if(string.IsNullOrEmpty(p_site))
        {
            p_site = "ALL";
        }
        if (string.IsNullOrEmpty(p_po))
        {
            p_po = "ALL";
        }
        if (string.IsNullOrEmpty(p_partno))
        {
            p_partno = "ALL";
        }

        using (OracleConnection conn = new OracleConnection(connString))
        {
            try
            {
                OracleCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BTS.BIZ_DATA_ENGINE.GETNEWTRIGGERS";
                cmd.Parameters.Add("p_site", OracleDbType.NVarchar2, 100).Value = p_site;
                cmd.Parameters.Add("p_po", OracleDbType.NVarchar2, 100).Value = p_po;
                cmd.Parameters.Add("p_partno", OracleDbType.NVarchar2, 100).Value = p_partno;
                cmd.Parameters.Add("p_username", OracleDbType.NVarchar2, 100).Value = userID;
                cmd.Parameters.Add("cur_trigdata", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                {
                    adapter.Fill(result);
                }
            }
            catch (OracleException ex)
            {
                ShowErrorMessage("Error:" + ex.Message);
            }
        }
        return result;
    }

    protected void AspNetPager_PageChanged(object sender, EventArgs e)
    {
        BindGridView("", "", "", false);
    }

    private void Search()
    {
        string p_site = RadioButtonList.SelectedValue;
        string p_po = TextPO.Text;
        string p_partno = TextPN.Text;

        ViewState["uploadData"] = null;
        BindGridView(p_site, p_po, p_partno, true);
        GridView.Columns[1].Visible = true;
    }

    protected void Search_Click(object sender, EventArgs e)
    {
        Search();
    }

    // Export Excel.
    protected void Excel_Click(object sender, EventArgs e)
    {
        try
        {
            data = ViewState["850DATA"] as DataTable;
            if (data != null)
            {
                var package = new ExcelPackage();
                var worksheet = package.Workbook.Worksheets.Add("Sheet1");
                worksheet.Cells["A1"].LoadFromDataTable(data, true);
                var stream = new MemoryStream();
                package.SaveAs(stream);
                stream.Position = 0;
                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment;filename=EDI850Commit" + DateTime.Now.ToString("_yyyyMMddHHmmss") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                using (stream)
                {
                    stream.WriteTo(Response.OutputStream);
                }                   
                Response.End();
            }
            else
            {
                ShowErrorMessage("The data is null!");
                return;
            }
        }
        catch (Exception ex)
        {
            ShowErrorMessage("Error:" + ex.Message);
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        // Empty implementation, to ensure that outside the GridView control when using won't throw InvalidOperationException.
    }

    // Upload Excel file data to the GridView.
    protected void Import_Click(object sender, ImageClickEventArgs e)
    {
        if(FileUpload.HasFile)
        {
            try
            {
                string fileName = Path.GetFileName(FileUpload.FileName);
                string fileExtension = Path.GetExtension(fileName).ToLower();
                // Check file type.
                if (fileExtension != ".xlsx")
                {
                    ShowErrorMessage("Please upload the correct file type!");
                    return;
                }
                // Rename file and save.
                string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
                string newFileName = fileNameWithoutExtension + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + ".xlsx";
                string filePath = Server.MapPath("~/Excel/EDI850Commit/") + newFileName;
                FileUpload.SaveAs(filePath);

                using (var package = new ExcelPackage(new FileInfo(filePath)))
                {
                    ExcelWorksheet worksheet = package.Workbook.Worksheets[0];
                    // Add columns.
                    foreach (var firstRowCell in worksheet.Cells[1, 1, 1, worksheet.Dimension.End.Column])
                    {
                        uploadedData.Columns.Add(firstRowCell.Text);
                    }
                    // Add rows.
                    int rowCount = worksheet.Dimension.End.Row;
                    for (int rowNum = 2; rowNum <= rowCount; rowNum++)
                    {
                        DataRow newRow = uploadedData.NewRow();
                        for (int colNum = 1; colNum <= worksheet.Dimension.End.Column; colNum++)
                        {
                            newRow[colNum - 1] = worksheet.Cells[rowNum, colNum].Text;
                        }
                        uploadedData.Rows.Add(newRow);
                    }
                    ShouldSkipRowDataBound = true;
                    GridView.Columns[1].Visible = false;
                    ViewState["uploadData"] = uploadedData;
                    BindGridView("", "", "", false);
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage("Error:" + ex.Message);
            }
        }
        else
        {
            ShowErrorMessage("Please upload the file!");
        }
    }

    // Update GridView data to the database.
    protected void Commit_Click(object sender, ImageClickEventArgs e)
    {
        uploadedData = ViewState["uploadData"] as DataTable;
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["OTMDB_Test"].ConnectionString;
        using (OracleConnection conn = new OracleConnection(connString))
        {
            try
            {
                conn.Open();
                using (OracleCommand cmd = conn.CreateCommand())
                {
                    if (uploadedData == null)
                    {
                        string sql = "UPDATE AAA_TEST SET PRODUCT_NAME=:commitDate,UNIT=:commitQty where PN='8214472'";
                        cmd.CommandText = sql;
                        foreach (GridViewRow row in GridView.Rows)
                        {
                            if (row.RowType == DataControlRowType.DataRow)
                            {
                                ControlCollection controls = row.Cells[2].Controls;
                                CheckBox checkbox = row.FindControl("chk_" + (row.RowIndex - 1)) as CheckBox;
                                CheckBox check = row.Cells[2].FindControl("chk_" + (row.RowIndex - 1)) as CheckBox;
                                //if (checkBox != null && checkBox.Checked)
                                //{
                                //    DataRow dataRow = data.Rows[row.RowIndex];
                                //    cmd.Parameters.Clear();
                                //    cmd.Parameters.Add(":commitDate", OracleDbType.Date).Value = row.Cells[12].Text;
                                //    cmd.Parameters.Add(":commitQty", OracleDbType.Int32).Value = row.Cells[13].Text;
                                //    cmd.ExecuteNonQuery();
                                //}
                            }
                        }
                    }
                    else
                    {
                        string sql = "INSERT INTO AAA_TEST VALUES (:P1, :P2, :P3, :P4, :P5, :P6, :P7, :P8, :P9)";
                        cmd.CommandText = sql;
                        foreach (DataRow row in uploadedData.Rows)
                        {
                            cmd.Parameters.Clear();
                            for (int i = 0; i < row.ItemArray.Length; i++)
                            {
                                OracleParameter param = new OracleParameter(":P" + (i + 1).ToString(), row[i]);
                                cmd.Parameters.Add(param);
                            }
                            cmd.ExecuteNonQuery();
                        }
                    }
                }     
            }
            catch (OracleException ex)
            {
                ShowErrorMessage("Error:" + ex.Message);
            }
            Search();
        }
    }

    // Add a new row of data.
    protected void GridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "AddNewRow")
        {

        }
    }

    // Enter edit mode.
    protected void GridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        GridView.EditIndex = e.NewEditIndex;
        BindGridView("", "", "", false);
    }

    // Cancel edit mode.
    protected void GridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        GridView.EditIndex = -1;
        BindGridView("", "", "", false);
    }

    // Updates the modified data into the GridView.
    protected void GridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string Date = (GridView.Rows[e.RowIndex].Cells[14].Controls[0] as TextBox).Text;
        string Qty = (GridView.Rows[e.RowIndex].Cells[15].Controls[0] as TextBox).Text;
        data = ViewState["850DATA"] as DataTable;
        DataRow row = data.Rows[e.RowIndex];

        DateTime commitDate;
        if (DateTime.TryParse(Date, out commitDate))
        {
            string formatDate = commitDate.ToString("yyyy-MM-dd");
            row[12] = formatDate;
        }
        else
        {
            ShowErrorMessage("Please enter a valid date!");
            e.Cancel = true;
            return;
        }

        int commitQty;
        if (int.TryParse(Qty, out commitQty))
        {
            row[13] = commitQty;
        }
        else
        {
            ShowErrorMessage("Please enter a valid quantity!");
            e.Cancel = true;
            return;
        }
        GridView.EditIndex = -1;
        BindGridView("", "", "", false);
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (ShouldSkipRowDataBound == false)
        {
            // Lock data while editing.
            if (e.Row.RowIndex == GridView.EditIndex)
            {
                for (int i = 2; i < e.Row.Cells.Count; i++)
                {
                    e.Row.Cells[i].Enabled = false;
                }
                e.Row.Cells[14].Enabled = true;
                e.Row.Cells[15].Enabled = true;
            }

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                // Insert selection control.
                CheckBox newCheckBox = new CheckBox();
                newCheckBox.ID = "chk_" + e.Row.RowIndex;
                e.Row.Cells[2].Controls.Add(newCheckBox);

                // Insert add control.
                ImageButton imageButton = new ImageButton();
                imageButton.ID = "imgBtn_" + e.Row.RowIndex;
                imageButton.ImageUrl = "~/Image/add.jpg";
                e.Row.Cells[3].Controls.Add(imageButton);

                // Set the Commit Date and the background color for the Commit Qty column. 
                DataControlFieldCell Commit_Date = e.Row.Cells[14] as DataControlFieldCell;
                DataControlFieldCell Commit_Qty = e.Row.Cells[15] as DataControlFieldCell;
                if (Commit_Date != null && Commit_Qty != null)
                {
                    Commit_Date.Style["background-color"] = "#FFFF99";
                    Commit_Qty.Style["background-color"] = "#FFFF99";
                }
            }
        }    
    }
    private void ShowErrorMessage(string errorMessage)
    {
        ScriptManager.RegisterStartupScript(this, GetType(), "ErrorScript", "alert('" + errorMessage + "');", true);
    }
}