﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_EDI855Commit : System.Web.UI.Page
{
    private DataTable data;
    protected void Page_Load(object sender, EventArgs e)
    {
        // Check whether the user is logged in.
        string UserID = Session["USERID"] as string;
        if (UserID == null)
        {
            Response.Redirect("~/Page/System/Login.aspx");
            return;
        }

        // The page is bound to the GridView when it first loads.
        if (!IsPostBack)
        {
            BindGridView("", "", "", false);
        }
    }

    private void BindGridView(string p_site, string p_po, string p_partno, bool isSearch)
    {
        data = Cache["855DATA"] as DataTable;
        if (data == null || isSearch == true)
        {
            string userID = Session["USERID"] as string;
            data = GetCommandDECSData(p_site, p_po, p_partno, userID);
            Cache["855DATA"] = data;// Store in the cache and apply the policy.
        }
        // Create the PagedDataSource object and set its properties.
        PagedDataSource pds = new PagedDataSource();
        AspNetPager.RecordCount = data.Rows.Count;
        pds.DataSource = data.DefaultView;
        pds.CurrentPageIndex = AspNetPager.CurrentPageIndex - 1;
        pds.PageSize = AspNetPager.PageSize;
        pds.AllowPaging = true;

        try
        {
            // Set the PagedDataSource object as the data source for the GridView and bind the data.
            GridView.DataSource = pds;
            GridView.DataBind();
        }
        catch (Exception ex)
        {
            string errorMessage = "An error occurred while binding the GridView:" + ex.Message;
            Response.Write("<script>alert('" + errorMessage + "');</script>");
        }
    }

    private void BindGridView_Excel()
    {
        data = Cache["855DATA"] as DataTable;
        GridView.DataSource = data;
        GridView.DataBind();
    }

    private void FormatGridWeb()
    {
        GridView.Columns.Add(new BoundField() { HeaderText = "Check", DataField = "Check" });
    }
    
    public DataTable GetCommandDECSData(string p_site, string p_po, string p_partno, string userID)
    {
        DataTable result = new DataTable();
        string connString = System.Configuration.ConfigurationManager.ConnectionStrings["BTSDB"].ConnectionString;

        if (string.IsNullOrEmpty(p_site))
        {
            p_site = "ALL";
        }
        if (string.IsNullOrEmpty(p_po))
        {
            p_po = "ALL";
        }
        if (string.IsNullOrEmpty(p_partno))
        {
            p_partno = "ALL";
        }

        using (OracleConnection conn = new OracleConnection(connString))
        {
            try
            {
                OracleCommand cmd = conn.CreateCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "BTS.BIZ_DATA_ENGINE.GETNEWTRIGGERS_BP";
                cmd.Parameters.Add("p_site", OracleDbType.NVarchar2, 100).Value = p_site;
                cmd.Parameters.Add("p_po", OracleDbType.NVarchar2, 100).Value = p_po;
                cmd.Parameters.Add("p_partno", OracleDbType.NVarchar2, 100).Value = p_partno;
                cmd.Parameters.Add("p_username", OracleDbType.NVarchar2, 100).Value = userID;
                cmd.Parameters.Add("cur_trigdata", OracleDbType.RefCursor).Direction = ParameterDirection.Output;

                using (OracleDataAdapter adapter = new OracleDataAdapter(cmd))
                {
                    adapter.Fill(result);
                }
            }
            catch (OracleException ex)
            {
                Response.Write("<script>alert('Error:" + ex.Message + "');</script>");
            }
        }
        return result;
    }

    protected void AspNetPager_PageChanged(object sender, EventArgs e)
    {
        BindGridView("", "", "", false);
    }

    protected void Search_Click(object sender, EventArgs e)
    {
        string p_site = RadioButtonList.SelectedValue;
        string p_po = TextPO.Text;
        string p_partno = TextPN.Text;

        BindGridView(p_site, p_po, p_partno, true);
    }

    protected void Save_Click(object sender, ImageClickEventArgs e)
    {
        // Update GridView data to the database.
    }

    protected void Excel_Click(object sender, EventArgs e)
    {
        try
        {
            BindGridView_Excel();
            if (data != null)
            {
                Response.ClearContent();
                Response.AddHeader("content-disposition", "attachment;filename=EDI850Commit" + DateTime.Now.ToString("_yyyyMMdd") + ".xls");
                Response.ContentType = "application/excel";
                System.IO.StringWriter sw = new System.IO.StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                GridView.RenderControl(htw);
                Response.Write(sw.ToString());
                Response.End();
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "alertMessage", "alert('The data is null!');", true);
                return;
            }
        }
        catch (Exception ex)
        {
            Response.Write("<script>alert('Error:" + ex.Message + "');</script>");
        }
    }

    public override void VerifyRenderingInServerForm(Control control)
    {
        // Empty implementation, to ensure that outside the GridView control when using won't throw InvalidOperationException.
    }

    protected void GridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "AddNewRow")
        {

        }
    }

    protected void GridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        this.GridView.EditIndex = e.NewEditIndex;
        BindGridView("", "", "", false);
    }

    protected void GridView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        this.GridView.EditIndex = -1;
        BindGridView("", "", "", false);
    }

    protected void GridView_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        string ETD = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[14].Controls[0])).Text;
        string OnWay= ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[15].Controls[0])).Text;
        string CommitQty = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[17].Controls[0])).Text;
        string Expedite_Flag = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[18].Controls[0])).Text;
        string Approveid = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[19].Controls[0])).Text;
        string Ship_Mode = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[20].Controls[0])).Text;
        string Rts_Flag = ((TextBox)(this.GridView.Rows[e.RowIndex].Cells[21].Controls[0])).Text;

        DateTime new_ETD = DateTime.Parse(ETD);
        int new_OnWay = int.Parse(OnWay);

        int new_commitQty;
        bool isParse = int.TryParse(CommitQty, out new_commitQty);
        if (isParse)
        {
            // Updates the modified data into the GridView.
        }
        else
        {
            Response.Write("<script>alert('Error:" + "Please enter a valid commit quantity!" + "');</script>");
        }
    }

    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowIndex == GridView.EditIndex)
        {
            for (int i = 4; i < e.Row.Cells.Count; i++)
            {
                e.Row.Cells[i].Enabled = false;
            }
            e.Row.Cells[14].Enabled = true;
            e.Row.Cells[15].Enabled = true;
            e.Row.Cells[16].Enabled = true;
            e.Row.Cells[17].Enabled = true;
            e.Row.Cells[18].Enabled = true;
            e.Row.Cells[19].Enabled = true;
            e.Row.Cells[20].Enabled = true;
            e.Row.Cells[21].Enabled = true;
        }
        else
        {
            for (int i = 4; i < e.Row.Cells.Count; i++)
            {
                e.Row.Cells[i].Enabled = false;
            }
        }
    }
}