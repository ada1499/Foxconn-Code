USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OMS_ALTER]    Script Date: 2025/4/9 �W�� 09:22:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Zhi-jie
-- Create date: 2025-02-17
-- Description:	OMS Alert
-- ============================================= 
ALTER PROCEDURE [dbo].[OMS_ALTER] 
	@FUNCTION VARCHAR(50)
AS
BEGIN
	DECLARE @HTML AS NVARCHAR(MAX) = '<html><head><style>table {width:100%; border-collapse:collapse;} th, td {border:1px solid black; padding:8px; text-align:left;}</style></head><body><table>', 
			@RowHTML AS NVARCHAR(MAX), 
			@SEND_TO AS VARCHAR(5000), @COPY_TO AS VARCHAR(5000), @SUBJECT AS VARCHAR(500), @BODY_STR AS VARCHAR(MAX), @FILENAME AS VARCHAR(100);	--Mail
	
	--Alter 3B18 not received. 
	IF @FUNCTION = '3B18_WITHOUT_RECEIVED' 
	BEGIN
		SET @HTML = @HTML + '<tr><th>MESSAGE_ID</th><th>SHIPMENT_ID</th><th>BU</th><th>SITE_NAME</th><th>INVENTORY_ITEM_NUMBER</th><th>PO_NUMBER</th><th>SHIPPED_QUANTITY</th><th>CREATEDT</th><th>SHIP_DATE</th><th>COMMIT_DELIVERY_DATE</th></tr>'; 

		SET @RowHTML = (
			SELECT '' 
				+ '<tr>' 
				+ '<td>' + MESSAGE_ID + '</td>' 
				+ '<td>' + SHIPMENT_ID + '</td>' 
				+ '<td>' + BU + '</td>' 
				+ '<td>' + SITE_NAME + '</td>' 
				+ '<td>' + INVENTORY_ITEM_NUMBER + '</td>' 
				+ '<td>' + PO_NUMBER + '</td>' 
				+ '<td>' + SHIPPED_QUANTITY + '</td>' 
				+ '<td>' + CREATEDT + '</td>' 
				+ '<td>' + SHIP_DATE + '</td>' 
				+ '<td>' + COMMIT_DELIVERY_DATE + '</td>' 
				+ '</tr>' 
			FROM 
				[dbo].[OTM_3B2RTS_MAIN] A 
			WHERE 
				TRANSMISSION_DATE > FORMAT(GETDATE(), 'yyyy-MM-dd') 
				AND TRANSMISSION_DATE < CONVERT(VARCHAR(19), DATEADD(HOUR, -1, GETDATE()), 120) 
				AND NOT EXISTS (SELECT 1 FROM [dbo].[OTM_FA_FROM_CISCO_MAIN] B WHERE A.MESSAGE_ID = B.REFERENCE_MESSAGE_ID) 
				AND NOT EXISTS (SELECT 1 FROM [dbo].[OTM_3B18_MAIN] C WHERE A.SHIPMENT_ID = C.SHIPMENT_ID) 
			FOR XML PATH(''), TYPE 
		).value('.', 'NVARCHAR(MAX)'); 

		SET @SEND_TO = 'wkhwajam@cisco.com,puddarra@cisco.com,inbound_otm_planners@cisco.com,inbound-otm-support@external.cisco.com,gsqs-deliver-it-support@cisco.com,
						b2b-covc-support@cisco.com,yangfan.zm.luo@mail.foxconn.com,catherine.j.yuan@mail.foxconn.com,leakoo.wj.li@mail.foxconn.com,tiger.xh.xiang@mail.foxconn.com,
						jamie.jq.ji@mail.foxconn.com,athena.x.cao@mail.foxconn.com,sue.xp.long@mail.foxconn.com,yan.y.li@mail.foxconn.com,iris.wf.xiao@mail.foxconn.com,
						cathy.x.qin@mail.foxconn.com,johnny.yp.wu@mail.foxconn.com,amy.ch.wang@mail.foxconn.com,server-pc-02@mail.foxconn.com,nsdi-server-mc@mail.foxconn.com,
						server-pc-01@mail.foxconn.com,savbu-switch-pc@mail.foxconn.com,cui-cui.feng@mail.foxconn.com,carry.hx.he@mail.foxconn.com,suki.j.hu@mail.foxconn.com,
						handsome.ht.zhang@mail.foxconn.com,nsdi-crbu-mc@mail.foxconn.com,sui-feng.chen@mail.foxconn.com,ammy.sx.yang@mail.foxconn.com,npic-mpm-assistant@mail.foxconn.com,
						mfgv-bpd-pc01@mail.foxconn.com,Tiffany@MISSING_DOMAIN,S.H.@MISSING_DOMAIN'; 
		SET @COPY_TO = 'anujs@cisco.com,kwang@cisco.com,ningli2@cisco.com,vivshi@cisco.com,stlai@cisco.com,catherine.mineur@foxconn.com,kitty.wp.liu@foxconn.com,
						rita.rr.xiao@foxconn.com,dora.x.li@mail.foxconn.com,jennie.hj.li@mail.foxconn.com,nsd-it-eai@mail.foxconn.com,zhao-feng.zhong@mail.foxconn.com,
						blair.sf.wu@foxconn.com,walker.jm.hao@foxconn.com,leo.yy.gu@mail.foxconn.com,david.zy.lu@foxconn.com,ailsa.xq.huang@mail.foxconn.com,
						yuna.yj.peng@foxconn.com,kiwi.lq.huang@foxconn.com,nsd-it-eai@mail.foxconn.com,ting.t.zhang@mail.foxconn.com,may.jm.lu@mail.foxconn.com,
						phyllis.x.jiang@mail.foxconn.com,power.mz.xu@mail.foxconn.com,jacky.yt.lo@mail.foxconn.com,xiao-hua.luo@mail.foxconn.com,alice.lh.ai@mail.foxconn.com,
						denise.xh.gu@mail.foxconn.com,claire.yx.yang@mail.foxconn.com,helena.qh.ruan@mail.foxconn.com,zhi-jie.chen@mail.foxconn.com'; 
		SET @SUBJECT = 'OTMAlert: These 3B2RTS were sent, but 3B18 were not received.'; 
		SET @FILENAME = 'System_Alter.txt'; 
	END

	IF @FUNCTION = 'RECEIVED_3B18_LIST' 
	BEGIN
		SET @HTML = @HTML + '<tr><th>SHIP_FROM</th><th>SHIP_TO</th><th>PO</th><th>PN</th><th>SHIPPED_QUANTITY</th><th>SHIP_DATE</th><th>DELIVERY_DATE</th><th>BU</th></tr>'; 

		SET @RowHTML = (
			SELECT '' 
				+ '<tr>' 
        		+ '<td>' + B.SHIP_FROM_LOCATION + '</td>' 
				+ '<td>' + B.SHIP_TO_NAME + '</td>' 
				+ '<td>' + A.ORDER_NUMBER + '</td>' 
				+ '<td>' + B.INVENTORY_ITEM_NUMBER + '</td>' 
				+ '<td>' + A.SHIPPED_QUANTITY + '</td>' 
				+ '<td>' + A.SHIP_DATE + '</td>' 
				+ '<td>' + A.SHIP_END_DATE + '</td>' 
				+ '<td>' + B.BU + '</td>' 
				+ '</tr>' 
			FROM [dbo].[OTM_3B18_MAIN] A 
			LEFT JOIN [dbo].[OTM_3B2RTS_MAIN] B ON A.SHIPMENT_ID = B.SHIPMENT_ID 
			WHERE A.TRANSMISSION_DATE > CONVERT(VARCHAR(19), DATEADD(HOUR, -26, GETDATE()), 120) 
			ORDER BY A.TRANSMISSION_DATE 
			FOR XML PATH(''), TYPE 
		).value('.', 'NVARCHAR(MAX)'); 

		SET @SEND_TO = 'kwang2@cisco.com,robin.j.liu@foxconn.com,johnny.yp.wu@foxconn.com,blair.sf.wu@foxconn.com,jennie.hj.li@foxconn.com,zhao-feng.zhong@mail.foxconn.com,
						claire.yx.yang@mail.foxconn.com,junlwang@cisco.com'; 
		SET @COPY_TO = 'zhi-jie.chen@mail.foxconn.com'; 
		SET @SUBJECT = 'OTMAlert: PCBA shipping pre-notice (3B18)' + CONVERT(VARCHAR(19), GETDATE(), 120); 
		SET @FILENAME = 'System_Alter.txt'; 
	END

	IF @FUNCTION = 'WITHOUT_PACKING_INFO'
	BEGIN
		SET @HTML = @HTML + '<tr><th>WERKS</th><th>VBELN</th><th>MATNR</th></tr>'; 

		SET @RowHTML = (
			SELECT '' 
				+ '<tr>' 
				+ '<td>' + WERKS + '</td>' + 
				+ '<td>' + VBELN + '</td>' + 
				+ '<td>' + MATNR + '</td>' + 
				+ '</tr>' 
			FROM [dbo].[OTM_CARTON_INFO] WHERE C_GROES IS NULL OR C_GROES = '' AND CREATE_DATE > DATEADD(DAY, -1, GETDATE()) 
			FOR XML PATH(''), TYPE 
		).value('.', 'NVARCHAR(MAX)'); 

		SET @SEND_TO = 'lily.zl.yang@fii-foxconn.com,annao.f.wang@fii-foxconn.com,mia.yj.li@mail.foxconn.com,teresa.l.chen@fii-foxconn.com,ellen.yy.hu@mail.foxconn.com,
						nina.l.zhang@fii-foxconn.com,nancy.l.zhong@mail.foxconn.com,vivian.ys.pan@mail.foxconn.com,jasper.j.guo@fii-foxconn.com,fanny.lf.xu@mail.foxconn.com,
						denise.xh.gu@mail.foxconn.com,eva.x.wang@mail.foxconn.com,novo.gf.feng@fii-foxconn.com,mary.qy.zhang@fii-foxconn.com,robin.j.liu@fii-foxconn.com,
						eva.bl.li@fii-foxconn.com,julie.j.xu@fii-foxconn.com,canny.cx.liu@fii-foxconn.com,rosanne.y.luo@fii-foxconn.com,kiwi.lq.huang@fii-foxconn.com,
						ailsa.xq.huang@fii-foxconn.com,david.zy.lu@fii-foxconn.com,mia.sl.qin@fii-foxconn.com,james.jq.lu@fii-foxconn.com,sean.yh.liu@fii-foxconn.com,
						quinn.jl.qin@fii-foxconn.com,judy.sh.ruan@mail.foxconn.com,victor.c.wu@fii-foxconn.com,andy.zw.he@fii-foxconn.com,sen-yang.han@fii-foxconn.com,
						austin.ch.yang@fii-foxconn.com,handy.hj.li@fii-foxconn.com,olivia.mm.cao@fii-foxconn.com,ashley.jy.hu@mail.foxconn.com,linda.p.li@fii-foxconn.com,
						jasmin.xz.lu@fii-foxconn.com,susan.z.he@fii-foxconn.com,camille.h.tang@fii-foxconn.com,mandy.ml.wang@fii-foxconn.com,chong-wen.qiu@mail.foxconn.com,
						sharon.xm.chen@mail.foxconn.com,jenny.yz.lu@fii-foxconn.com,etta.m.zhou@mail.foxconn.com,dorine.h.jin@mail.foxconn.com,nana.bn.chen@mail.foxconn.com,
						beryl.by.fu@fii-foxconn.com,leo.yy.gu@fii-foxconn.com,jasmin.xz.lu@fii-foxconn.com,fiona.lt.li@fii-foxconn.com,emma.z.zhang@mail.foxconn.com,
						cindy.hc.cheng@fii-foxconn.com,agnes.hf.cheng@fii-foxconn.com,kylie.hc.li@fii-foxconn.com,uni.yx.yang@mail.foxconn.com,sophie.h.li@mail.foxconn.com,
						gianna.yz.qin@mail.foxconn.com,sandy.yr.lin@fii-foxconn.com,jacky.yt.lo@mail.foxconn.com,andrew.hg.wu@mail.foxconn.com,ellie.ls.pan@mail.foxconn.com,
						helena.qh.ruan@mail.foxconn.com,jennie.sy.ruan@mail.foxconn.com,almira.rj.he@mail.foxconn.com,amy.ql.zou@mail.foxconn.com,nsd-log-export02@mail.foxconn.com,
						kitty.wp.liu@fii-foxconn.com'; 
		SET @COPY_TO = 'zhi-jie.chen@mail.foxconn.com'; 
		SET @SUBJECT = 'OTMAlert: The part numbers below do not have packaging info, please maintain in SAP.'; 
		SET @FILENAME = 'System_Alter.txt'; 
	END

	SET @HTML = @HTML + @RowHTML + '</table></body></html>'; 
	SET @BODY_STR = @HTML; 

	IF @FUNCTION = 'WITHOUT_TRACKING_NUMBER'
	BEGIN
		SET @HTML = @HTML + '<tr><th>DELIVERY_ID</th><th>INVENTORY_ITEM_NUMBER</th><th>PLANT</th></tr>'; 

		SET @RowHTML = (
			SELECT '' 
				+ '<tr>' 
				+ '<td>' + MAX(A.DELIVERY_ID) + '</td>' + 
				+ '<td>' + MAX(A.INVENTORY_ITEM_NUMBER) + '</td>' + 
				+ '<td>' + MAX(A.PLANT) + '</td>' + 
				+ '</tr>' 
			FROM [dbo].[OTM_3B2SC_LINE] A 
			JOIN [dbo].[OTM_3B2_MAIN] B ON A.MESSAGE_ID = B.MESSAGE_ID 
			WHERE (A.TRACKING_NUMBER IS NULL OR TRACKING_NUMBER = '') AND B.SENDER_DUNS_NUMBER != '544734668' AND B.PLANT != 'SHKF' 
			GROUP BY A.DELIVERY_ID 
			FOR XML PATH(''), TYPE 
		).value('.', 'NVARCHAR(MAX)'); 

		SET @SEND_TO = 'lily.zl.yang@fii-foxconn.com,annao.f.wang@fii-foxconn.com,mia.yj.li@mail.foxconn.com,teresa.l.chen@fii-foxconn.com,ellen.yy.hu@mail.foxconn.com,
						nina.l.zhang@fii-foxconn.com,nancy.l.zhong@mail.foxconn.com,vivian.ys.pan@mail.foxconn.com,jasper.j.guo@fii-foxconn.com,fanny.lf.xu@mail.foxconn.com,
						denise.xh.gu@mail.foxconn.com,eva.x.wang@mail.foxconn.com,novo.gf.feng@fii-foxconn.com,mary.qy.zhang@fii-foxconn.com,robin.j.liu@fii-foxconn.com,
						eva.bl.li@fii-foxconn.com,julie.j.xu@fii-foxconn.com,canny.cx.liu@fii-foxconn.com,rosanne.y.luo@fii-foxconn.com,kiwi.lq.huang@fii-foxconn.com,
						ailsa.xq.huang@fii-foxconn.com,david.zy.lu@fii-foxconn.com,mia.sl.qin@fii-foxconn.com,james.jq.lu@fii-foxconn.com,sean.yh.liu@fii-foxconn.com,
						quinn.jl.qin@fii-foxconn.com,judy.sh.ruan@mail.foxconn.com,victor.c.wu@fii-foxconn.com,andy.zw.he@fii-foxconn.com,sen-yang.han@fii-foxconn.com,
						austin.ch.yang@fii-foxconn.com,handy.hj.li@fii-foxconn.com,olivia.mm.cao@fii-foxconn.com,ashley.jy.hu@mail.foxconn.com,linda.p.li@fii-foxconn.com,
						jasmin.xz.lu@fii-foxconn.com,susan.z.he@fii-foxconn.com,camille.h.tang@fii-foxconn.com,mandy.ml.wang@fii-foxconn.com,chong-wen.qiu@mail.foxconn.com,
						sharon.xm.chen@mail.foxconn.com,jenny.yz.lu@fii-foxconn.com,etta.m.zhou@mail.foxconn.com,dorine.h.jin@mail.foxconn.com,nana.bn.chen@mail.foxconn.com,
						beryl.by.fu@fii-foxconn.com,leo.yy.gu@fii-foxconn.com,jasmin.xz.lu@fii-foxconn.com,fiona.lt.li@fii-foxconn.com,emma.z.zhang@mail.foxconn.com,
						cindy.hc.cheng@fii-foxconn.com,agnes.hf.cheng@fii-foxconn.com,kylie.hc.li@fii-foxconn.com,uni.yx.yang@mail.foxconn.com,sophie.h.li@mail.foxconn.com,
						gianna.yz.qin@mail.foxconn.com,sandy.yr.lin@fii-foxconn.com,jacky.yt.lo@mail.foxconn.com,andrew.hg.wu@mail.foxconn.com,ellie.ls.pan@mail.foxconn.com,
						helena.qh.ruan@mail.foxconn.com,jennie.sy.ruan@mail.foxconn.com,almira.rj.he@mail.foxconn.com,amy.ql.zou@mail.foxconn.com,nsd-log-export02@mail.foxconn.com,
						kitty.wp.liu@fii-foxconn.com'; 
		SET @COPY_TO = 'zhi-jie.chen@mail.foxconn.com'; 
		SET @SUBJECT = 'OTMAlert: These 3B2SC shipping data missing tracking_number. Please check and contact SFC IT.'; 
		SET @FILENAME = 'System_Alter.txt'; 
	END

	IF @RowHTML IS NULL 
	BEGIN
		RETURN; 
	END

	SET @HTML = @HTML + @RowHTML + '</table></body></html>'; 
	SET @BODY_STR = @HTML; 

	INSERT INTO [dbo].[OMS_SEND_MAIL] (SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
	SELECT @SEND_TO, @COPY_TO, @SUBJECT, @BODY_STR, @FILENAME; 
END
