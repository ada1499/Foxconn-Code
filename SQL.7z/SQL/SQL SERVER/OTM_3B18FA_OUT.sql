USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B18FA_OUT]    Script Date: 2025/4/9 �W�� 09:25:59 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Zhi-jie
-- Create date: 2024-12-10
-- Description:	Generate 3B18FA
-- =============================================
ALTER PROCEDURE [dbo].[OTM_3B18FA_OUT]
	@Messageid VARCHAR(30)
AS
BEGIN
	DECLARE @doc AS XML, @SHIP_DATE_WITH_TIMEZONE AS VARCHAR(10);

	BEGIN TRY
		IF OBJECT_ID('tempdb..#OTM_FA_TO_CISCO') IS NOT NULL
			DROP TABLE #OTM_FA_TO_CISCO;

		SELECT * INTO #OTM_FA_TO_CISCO FROM [dbo].[OTM_FA_TO_CISCO] WHERE MESSAGE_ID = @Messageid;

		SET @SHIP_DATE_WITH_TIMEZONE = (SELECT TOP 1 SHIP_DATE_WITH_TIMEZONE FROM [dbo].[OTM_3B2SC_MAPPING] A JOIN #OTM_FA_TO_CISCO B ON A.SENDER_DUNS_NUMBER = B.SENDER_DUNS_NUMBER);

		SELECT @doc='<?xml version="1.0"?>
		<FunctionalAcknowledgement>
		  <DocumentHeader>
			<CorrelationInformation>
			  <RequestingDocumentInformation>
				<RequestingDocumentInstanceIdentifier>' + PLANT + '</RequestingDocumentInstanceIdentifier>
			  </RequestingDocumentInformation>
			</CorrelationInformation>
			<DocumentInformation>
			  <Creation>' + REPLACE(TRANSMISSION_DATE, ' ', 'T') + @SHIP_DATE_WITH_TIMEZONE + '</Creation>
			  <DocumentIdentification>
				<StandardDocumentIdentification>
				  <Standard>PROPRIETARY</Standard>
				  <Version>FAV06.21.2012</Version>
				</StandardDocumentIdentification>
			  </DocumentIdentification>
			</DocumentInformation>
			<Receiver>
			  <PartnerIdentification>
				<Name>Cisco</Name>
				<AlternativeIdentifier>
				  <Authority>DUNS</Authority>
				  <Identifier>' + RECEIVER_DUNS_NUMBER + '</Identifier>
				</AlternativeIdentifier>
			  </PartnerIdentification>
			</Receiver>
			<Sender>
			  <PartnerIdentification>
				<AlternativeIdentifier>
				  <Authority>DUNS</Authority>
				  <Identifier>' + SENDER_DUNS_NUMBER + '</Identifier>
				</AlternativeIdentifier>
			  </PartnerIdentification>
			</Sender>
		  </DocumentHeader>
		  <ActionControl>
			<ActionIdentity>
			  <GlobalBusinessActionCode>Functional Acknowledgement</GlobalBusinessActionCode>
			</ActionIdentity>
			<MessageTrackingIdentification>' + REQUEST_MESSAGE_ID + '</MessageTrackingIdentification>
		  </ActionControl>
		  <FailedInitiatingDocumentDateTime>
			<DateTimeStamp>' + REPLACE(FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss'), ' ','T') + @SHIP_DATE_WITH_TIMEZONE + '</DateTimeStamp>
		  </FailedInitiatingDocumentDateTime>
		  <ProcessIdentity>
			<GlobalProcessIndicatorCode>3B18</GlobalProcessIndicatorCode>
			<InstanceIdentifier>' + MESSAGE_ID + '</InstanceIdentifier>
			<VersionIdentifier>V2.00</VersionIdentifier>
		  </ProcessIdentity>
		  <ProcessStatus>
			<Status>FAILED</Status>
			<ReasonCode>' + ERROR_CODE + '</ReasonCode>
			<ReasonDescription>' + ERROR_MESSAGE + '</ReasonDescription>
		  </ProcessStatus>
		  <DocumentGenerationDateTime>
			<DateTimeStamp>' + REPLACE(FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss'), ' ', 'T') + @SHIP_DATE_WITH_TIMEZONE + '</DateTimeStamp>
		  </DocumentGenerationDateTime>
		  <DocumentIdentifier>
			<ProprietaryDocumentIdentifier>' + DELIVERY_ID + '</ProprietaryDocumentIdentifier>
		  </DocumentIdentifier>
		  <DocumentLineInformation>
			<DocumentLineReference>
			  <Identifier>' + PO_NUMBER + '</Identifier>
			</DocumentLineReference>
		  </DocumentLineInformation>
		</FunctionalAcknowledgement>
		'
		FROM #OTM_FA_TO_CISCO; 

		BEGIN TRANSACTION OTM_3B18FA_OUT; 

		UPDATE 
			[dbo].[OTM_FA_TO_CISCO] 
		SET 
			FILE_NAME = 'IIAK-' + MESSAGE_ID + '-0-' + PLANT + '-' + SENDER_DUNS_NUMBER  + '-' + FORMAT(GETDATE(),'yyMMddHHmmss') + '.xml', 
			SENDFLAG = 'Y' 
		WHERE MESSAGE_ID = @Messageid; 

		INSERT INTO [dbo].[TB_B2B_FILE](F_PLANT, F_DOCID, F_TYPE, F_INOUT, F_FILENAME, F_DOC, F_DOCTYPE, F_DOCTIMESTAMP) 
		SELECT 'BTS', MESSAGE_ID, 'FA-3B18', 'OUT', FILE_NAME, CONVERT(VARBINARY(MAX), @doc), 'XML', FORMAT(GETDATE(),'yyyy-MM-dd HH:mm:ss') 
		FROM [dbo].[OTM_FA_TO_CISCO] 
		WHERE MESSAGE_ID = @Messageid; 

		COMMIT TRANSACTION OTM_3B18FA_OUT; 
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION OTM_3B18FA_OUT; 

		INSERT INTO [dbo].[OMS_SEND_MAIL](SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
		SELECT 'zhi-jie.chen@mail.foxconn.com', NULL, 'Generate 3B18 FA file error. MessageID: ' + @Messageid + '. [dbo].[OTM_3B18FA_OUT]', ERROR_MESSAGE(), 'System_Alter.txt'; 

		RETURN; 
	END CATCH
END
