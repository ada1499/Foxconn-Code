USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B2RTS_OUT]    Script Date: 2025/4/9 �W�� 09:26:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Zhi-jie
-- Create date: 2024-12-12
-- Description:	Generate 3B2RTS
-- =============================================
ALTER PROCEDURE [dbo].[OTM_3B2RTS_OUT] 
	@Messageid AS VARCHAR(30) 
AS
BEGIN
	DECLARE @doc AS XML, @ShippingContainer AS NVARCHAR(MAX), --Xml
			@SHIPMENT_MODE AS VARCHAR(100), @APPROVEID AS VARCHAR(100), @REFERENCE_MESSAGE_ID AS VARCHAR(100), @ITEM_DESCRIPTION AS VARCHAR(200); --Mapping

	BEGIN TRY
		IF OBJECT_ID('tempdb..#OTM_3B2RTS_MAIN') IS NOT NULL
			DROP TABLE #OTM_3B2RTS_MAIN;

		SELECT * INTO #OTM_3B2RTS_MAIN FROM [dbo].[OTM_3B2RTS_MAIN] WHERE MESSAGE_ID = @Messageid; 

		IF OBJECT_ID('tempdb..#OTM_3B2RTS_ITEM') IS NOT NULL
			DROP TABLE #OTM_3B2RTS_ITEM;

		SELECT * INTO #OTM_3B2RTS_ITEM FROM [dbo].[OTM_3B2RTS_ITEM] WHERE MESSAGE_ID = @Messageid; 

		IF OBJECT_ID('tempdb..#OTM_3B2RTS_MAPPING') IS NOT NULL
			DROP TABLE #OTM_3B2RTS_MAPPING;

		SELECT * INTO #OTM_3B2RTS_MAPPING FROM [dbo].[OTM_3B2RTS_MAPPING] A WHERE EXISTS (SELECT 1 FROM #OTM_3B2RTS_MAIN B WHERE A.SHIP_FROM_LOCATION = B.SHIP_FROM_LOCATION AND A.SHIP_TO_NAME = B.SHIP_TO_NAME); 

		SELECT 
			@SHIPMENT_MODE = CASE WHEN UPPER(SHIP_VIA) = 'AIR' THEN '<dsm:ShipmentMode>AIR</dsm:ShipmentMode>' WHEN UPPER(SHIP_VIA) = 'SEA' THEN '<dsm:ShipmentMode>COO</dsm:ShipmentMode>' ELSE '' END,
			@APPROVEID = CASE WHEN APPROVEID IS NOT NULL AND APPROVEID <> '' THEN '<udc:Revision>' + APPROVEID + '</udc:Revision>' ELSE '' END,
			@REFERENCE_MESSAGE_ID = CASE WHEN REFERENCE_MESSAGE_ID IS NOT NULL AND REFERENCE_MESSAGE_ID <> '' THEN '<ssdh:HeaderVersion>' + REFERENCE_MESSAGE_ID + '</ssdh:HeaderVersion>' ELSE '' END,
			@ITEM_DESCRIPTION = CASE WHEN ITEM_DESCRIPTION IS NOT NULL AND ITEM_DESCRIPTION <> '' THEN '<updi:ProductName>' + ITEM_DESCRIPTION + '</updi:ProductName>' ELSE '' END
		FROM #OTM_3B2RTS_MAIN;

		SET @ShippingContainer = (
			SELECT (
				SELECT '
						<ShippingContainer>
						<Identifier>' + C.CONTAINER_ID + '</Identifier>
						<upd:Linear>
							<upd:Height>
							<upd:UnitOfMeasure>' + C.CONTAINER_HEIGHT_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + C.CONTAINER_HEIGHT + '</upd:Value>
							</upd:Height>
							<upd:Length>
							<upd:UnitOfMeasure>' + C.CONTAINER_LENGTH_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + C.CONTAINER_LENGTH + '</upd:Value>
							</upd:Length>
							<upd:Width>
							<upd:UnitOfMeasure>' + C.CONTAINER_WIDTH_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + C.CONTAINER_WIDTH + '</upd:Value>
							</upd:Width>
						</upd:Linear>
						<dl:MassPhysicalDimension>
							<upd:Weight>
							<upd:UnitOfMeasure>' + C.CONTAINER_WEIGHT_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + C.CONTAINER_WEIGHT + '</upd:Value>
							</upd:Weight>
						</dl:MassPhysicalDimension>
						<rpkt:PackageType>' + C.CONTAINER_TYPE + '</rpkt:PackageType>
						<ShippingContainerItem>
							<udc:BusinessDocumentReference>
							<udct:DocumentType>PUO</udct:DocumentType>
							<udc:Identifier>' + D.PO_NUMBER + '</udc:Identifier>
							<udc:Line>' + D.EXPEDITE_FLAG + '</udc:Line>
							' + @APPROVEID + '
							<udc:SubLine>' + D.SHIPMENT_ID + '</udc:SubLine>
							</udc:BusinessDocumentReference>
							<DocumentSubLineLotShipReference>
							<udc:DateTime>' + CONVERT(varchar(10), D.PROMISE_DELIVERY_DATE, 120) + 'T07:00:00' + E.SHIP_DATE_WITH_TIMEZONE + '</udc:DateTime>
							<udct:DocumentType>PUO</udct:DocumentType>
							<udc:Identifier>' + D.ITEM_NUMBER + '</udc:Identifier>
							<ShippedLotQuantity>' + C.CONTAINERT_QUANTITY + '</ShippedLotQuantity>
							</DocumentSubLineLotShipReference>
							<HazardousMaterial>false</HazardousMaterial>
							<Identifier>' + D.PO_LINE_NUMBER + '</Identifier>
							<updi:ProductIdentification>
							' + @ITEM_DESCRIPTION + '
							<ulc:AlternativeIdentifier>
								<ulc:Authority>Inventory Item Number</ulc:Authority>
								<ulc:Identifier>' + D.INVENTORY_ITEM_NUMBER + '</ulc:Identifier>
							</ulc:AlternativeIdentifier>
							<ulc:AlternativeIdentifier>
								<ulc:Authority>BU</ulc:Authority>
								<ulc:Identifier>' + D.BU + '</ulc:Identifier>
							</ulc:AlternativeIdentifier>
							<ulc:AlternativeIdentifier>
								<ulc:Authority>PF</ulc:Authority>
								<ulc:Identifier>' + D.PRODUCTNAME + '</ulc:Identifier>
							</ulc:AlternativeIdentifier>
							</updi:ProductIdentification>
							<ShippedQuantity>' + C.CONTAINERT_QUANTITY + '</ShippedQuantity>
							<uuom:UnitOfMeasure>EAC</uuom:UnitOfMeasure>
						</ShippingContainerItem>
						</ShippingContainer>
						'
				FROM #OTM_3B2RTS_ITEM C 
				LEFT JOIN #OTM_3B2RTS_MAIN D ON C.MESSAGE_ID = D.MESSAGE_ID
				LEFT JOIN #OTM_3B2RTS_MAPPING E ON D.SHIP_FROM_LOCATION = E.SHIP_FROM_LOCATION AND D.SHIP_TO_NAME = E.SHIP_TO_NAME
				FOR XML PATH(''), TYPE
			).value('.', 'NVARCHAR(MAX)')
		);

		SELECT @doc = '<?xml version="1.0"?>
			<AdvanceShipmentNotification
				xmlns:dsfr="urn:rosettanet:specification:domain:Procurement:SpecialFulfillmentRequest:xsd:codelist:01.03"
				xmlns:dft="urn:rosettanet:specification:domain:Procurement:FinanceTerms:xsd:codelist:01.03"
				xmlns:upi="urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16"
				xmlns:dwbsf="urn:rosettanet:specification:domain:Manufacturing:WaferBackSideFinish:xsd:codelist:01.04"
				xmlns:dmrcc="urn:rosettanet:specification:domain:Manufacturing:ReplacementCompatibilityCode:xsd:codelist:01.01"
				xmlns:rptc="urn:rosettanet:specification:domain:Shared:PricingTypeCode:xsd:codelist:01.04"
				xmlns:dprt="urn:rosettanet:specification:domain:Manufacturing:ProcessType:xsd:codelist:01.03"
				xmlns:dbpq="urn:rosettanet:specification:domain:Procurement:BookPriceQualifier:xsd:codelist:01.04"
				xmlns:ud="urn:rosettanet:specification:universal:Dates:xsd:schema:01.03"
				xmlns:dsh="urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04"
				xmlns:dic="urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03"
				xmlns:upri="urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11"
				xmlns:dwipl="urn:rosettanet:specification:domain:Manufacturing:WorkInProcessLocation:xsd:codelist:01.03"
				xmlns:dms="urn:rosettanet:specification:domain:Manufacturing:MarkSide:xsd:codelist:01.03"
				xmlns:rssl="urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01"
				xmlns:dpsr="urn:rosettanet:specification:domain:Procurement:ProductSubstitutionReason:xsd:codelist:01.03"
				xmlns:dccc="urn:rosettanet:specification:domain:Procurement:CreditCardClassification:xsd:codelist:01.03"
				xmlns:udc="urn:rosettanet:specification:universal:Document:xsd:schema:01.12"
				xmlns:dsic="urn:rosettanet:specification:domain:Manufacturing:SpecialInstructionCategory:xsd:codelist:01.04"
				xmlns:dit="urn:rosettanet:specification:domain:Procurement:InventoryType:xsd:codelist:01.03"
				xmlns:urss="urn:rosettanet:specification:system:xml:1.0"
				xmlns:dwp="urn:rosettanet:specification:domain:Manufacturing:WaferPassivation:xsd:codelist:01.04"
				xmlns:dmt="urn:rosettanet:specification:domain:Manufacturing:MarkType:xsd:codelist:01.03"
				xmlns:sft="urn:rosettanet:specification:system:TPIRFileType:xsd:codelist:01.01"
				xmlns:dptt="urn:rosettanet:specification:domain:Logistics:PortType:xsd:codelist:01.03"
				xmlns:dcr="urn:rosettanet:specification:domain:Manufacturing:ChangeReason:xsd:codelist:01.04"
				xmlns:udct="urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13"
				xmlns:dslt="urn:rosettanet:specification:domain:Procurement:SaleType:xsd:codelist:01.04"
				xmlns:dl="urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22"
				xmlns:utt="urn:rosettanet:specification:universal:TaxType:xsd:codelist:01.02"
				xmlns:dwqr="urn:rosettanet:specification:domain:Manufacturing:WaferQualityRating:xsd:codelist:01.03"
				xmlns:dnecc="urn:rosettanet:specification:domain:Logistics:NationalExportControlClassification:xsd:codelist:01.03"
				xmlns="urn:rosettanet:specification:interchange:AdvanceShipmentNotification:xsd:schema:02.04"
				xmlns:sha="urn:rosettanet:specification:domain:Shared:xsd:schema:01.17"
				xmlns:dr="urn:rosettanet:specification:domain:Procurement:Response:xsd:codelist:01.04"
				xmlns:dcrt="urn:rosettanet:specification:domain:Procurement:CustomerType:xsd:codelist:01.03"
				xmlns:udt="urn:rosettanet:specification:universal:DataType:xsd:schema:01.04"
				xmlns:dsm="urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05"
				xmlns:dldr="urn:rosettanet:specification:domain:Logistics:LotDiscrepancyReason:xsd:codelist:01.03"
				xmlns:uuom="urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04"
				xmlns:rfob="urn:rosettanet:specification:domain:Shared:FreeOnBoard:xsd:codelist:01.01"
				xmlns:dp="urn:rosettanet:specification:domain:Procurement:xsd:schema:02.27"
				xmlns:ssdh="urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23"
				xmlns:drl="urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03"
				xmlns:dcst="urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03"
				xmlns:ul="urn:rosettanet:specification:universal:Language:xsd:codelist:01.02"
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xmlns:dst="urn:rosettanet:specification:domain:Procurement:ShipmentTerms:xsd:codelist:01.03"
				xmlns:dlit="urn:rosettanet:specification:domain:Logistics:InstructionType:xsd:codelist:01.00"
				xmlns:uwt="urn:rosettanet:specification:universal:WeightType:xsd:codelist:01.02"
				xmlns:ri="urn:rosettanet:specification:domain:Shared:Interval:xsd:codelist:01.01"
				xmlns:dpc="urn:rosettanet:specification:domain:Procurement:PaymentCondition:xsd:codelist:01.03"
				xmlns:st="http://www.ascc.net/xml/schematron"
				xmlns:drlc="urn:rosettanet:specification:domain:Logistics:ReturnLabelCode:xsd:codelist:01.03"
				xmlns:ddpt="urn:rosettanet:specification:domain:Manufacturing:DevicePackageType:xsd:codelist:01.03"
				xmlns:ulc="urn:rosettanet:specification:universal:Locations:xsd:schema:01.04"
				xmlns:dte="urn:rosettanet:specification:domain:Procurement:TransportEvent:xsd:codelist:01.03"
				xmlns:dlqc="urn:rosettanet:specification:domain:Manufacturing:LotQuantityClassification:xsd:codelist:01.04"
				xmlns:rict="urn:rosettanet:specification:domain:Shared:InvoiceChargeType:xsd:codelist:01.02"
				xmlns:dpcm="urn:rosettanet:specification:domain:Procurement:PurchaseMethod:xsd:codelist:01.03"
				xmlns:uat="urn:rosettanet:specification:universal:AbstractType:xsd:schema:01.02"
				xmlns:drwt="urn:rosettanet:specification:domain:Manufacturing:RawWaferType:xsd:codelist:01.03"
				xmlns:det="urn:rosettanet:specification:domain:Manufacturing:EquipmentType:xsd:codelist:01.03"
				xmlns:ume="urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06"
				xmlns:dtec="urn:rosettanet:specification:domain:Procurement:TaxExemptionCode:xsd:codelist:01.03"
				xmlns:dlt="urn:rosettanet:specification:domain:Manufacturing:LotType:xsd:codelist:01.04"
				xmlns:rmat="urn:rosettanet:specification:domain:Shared:MonetaryAmountType:xsd:codelist:01.01"
				xmlns:dpcmp="urn:rosettanet:specification:domain:Manufacturing:PCMParmType:xsd:codelist:01.04"
				xmlns:uc="urn:rosettanet:specification:universal:Country:xsd:codelist:01.02"
				xmlns:dscd="urn:rosettanet:specification:domain:Logistics:ShipmentChangeDisposition:xsd:codelist:01.03"
				xmlns:dfe="urn:rosettanet:specification:domain:Procurement:ForecastEvent:xsd:codelist:01.03"
				xmlns:umtq="urn:rosettanet:specification:universal:MimeTypeQualifier:xsd:codelist:01.02"
				xmlns:dtq="urn:rosettanet:specification:domain:Procurement:TotalQualifier:xsd:codelist:01.03"
				xmlns:dltcc="urn:rosettanet:specification:domain:Procurement:LeadTimeClassificationCode:xsd:codelist:01.03"
				xmlns:rpkt="urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01"
				xmlns:dpdt="urn:rosettanet:specification:domain:Procurement:DateType:xsd:codelist:01.00"
				xmlns:da="urn:rosettanet:specification:domain:Manufacturing:Axis:xsd:codelist:01.03"
				xmlns:uci="urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04"
				xmlns:dsd="urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02"
				xmlns:dfpt="urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03"
				xmlns:upd="urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07"
				xmlns:dtrt="urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06"
				xmlns:dm="urn:rosettanet:specification:domain:Manufacturing:xsd:schema:02.27"
				xmlns:rpktc="urn:rosettanet:specification:domain:Shared:PackageTypeCode:xsd:codelist:01.01"
				xmlns:dpe="urn:rosettanet:specification:domain:Procurement:Event:xsd:codelist:01.00"
				xmlns:dacc="urn:rosettanet:specification:domain:Procurement:AccountClassification:xsd:codelist:01.03"
				xmlns:ucr="urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03"
				xmlns:dsdc="urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03"
				xmlns:dfrt="urn:rosettanet:specification:domain:Procurement:ForecastReferenceType:xsd:codelist:01.03"
				xmlns:updi="urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04"
				xmlns:dtt="urn:rosettanet:specification:domain:Procurement:TransactionType:xsd:codelist:01.04"
				xmlns:dmct="urn:rosettanet:specification:domain:Manufacturing:ComponentType:xsd:codelist:01.02"
				xmlns:rpm="urn:rosettanet:specification:domain:Shared:PaymentMethod:xsd:codelist:01.02"
				xmlns:dpiac="urn:rosettanet:specification:domain:Logistics:PortIdentifierAuthorityCode:xsd:codelist:01.03"
				xmlns:dad="urn:rosettanet:specification:domain:Manufacturing:AttachmentDescription:xsd:codelist:01.03"
				xmlns:ucs="urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02">
				<AdvanceShipment>
				<PurchasedBy>
					<upi:SpecifiedFullPartner>
					<upi:PartnerIdentification>
						<upi:PartnerName>' + B.PARTNER_NAME + '</upi:PartnerName>
						<ulc:AlternativeIdentifier>
						<ulc:Authority>Requestor_ORG</ulc:Authority>
						<ulc:Identifier>' + B.REQUESTOR_ORG + '</ulc:Identifier>
						</ulc:AlternativeIdentifier>
					</upi:PartnerIdentification>
					</upi:SpecifiedFullPartner>
				</PurchasedBy>
				<ShipFrom>
					<upi:SpecifiedFullPartner>
					<ulc:Location>
						<ulc:AlternativeIdentifier>
						<ulc:Authority>Ship from Location</ulc:Authority>
						<ulc:Identifier>' + A.SHIP_FROM_LOCATION + '</ulc:Identifier>
						</ulc:AlternativeIdentifier>
					</ulc:Location>
					<upi:PartnerIdentification>
						<udt:DUNS>' + A.SENDER_DUNS_NUMBER + '</udt:DUNS>
					</upi:PartnerIdentification>
					</upi:SpecifiedFullPartner>
				</ShipFrom>
				<Shipment>
					<CarrierCode>DEF</CarrierCode>
					<Identifier></Identifier>
					<NumberOfShippingContainers>0</NumberOfShippingContainers>
					<dl:ShipmentDate>
					<dl:ShipDate>' + REPLACE(A.SHIP_DATE,' ','T') + B.SHIP_DATE_WITH_TIMEZONE + '</dl:ShipDate>
					<dsdc:ShipDateCode>' + A.SHIPDATE_CODE + '</dsdc:ShipDateCode>
					</dl:ShipmentDate>
					' + @SHIPMENT_MODE + '
					' + @ShippingContainer + '
					<rssl:ShippingServiceLevel>GRO</rssl:ShippingServiceLevel>
					<ShipTo>
					<upi:SpecifiedFullPartner/>
					</ShipTo>
					<TransportedBy>
					<upi:SpecifiedFullPartner/>
					</TransportedBy>
				</Shipment>
				<SoldBy>
					<upi:SpecifiedFullPartner/>
				</SoldBy>
				</AdvanceShipment>
				<ssdh:DocumentHeader>
				<ssdh:DocumentInformation>
					<ssdh:Creation>' + REPLACE(A.TRANSMISSION_DATE,' ','T') + B.SHIP_DATE_WITH_TIMEZONE + '</ssdh:Creation>
					<ssdh:DocumentIdentification>
					<ssdh:Identifier>' + A.MESSAGE_ID + '</ssdh:Identifier>
					<ssdh:Type>3B2 RTS</ssdh:Type>
					<ssdh:StandardDocumentIdentification>
						<ssdh:Standard>RosettaNet</ssdh:Standard>
						<ssdh:Version>11.02.00</ssdh:Version>
					</ssdh:StandardDocumentIdentification>
					</ssdh:DocumentIdentification>
				</ssdh:DocumentInformation>
				' + @REFERENCE_MESSAGE_ID + '
				<ssdh:Receiver>
					<ssdh:BusinessServiceInformation>
					<ssdh:ActionName>Request</ssdh:ActionName>
					<ssdh:ProcessIdentifier>3B2 - Ready to Ship (V11.02.00)</ssdh:ProcessIdentifier>
					<ssdh:ServiceName>3B2 Ready to Ship</ssdh:ServiceName>
					</ssdh:BusinessServiceInformation>
					<upi:PartnerIdentification>
					<udt:DUNS>' + A.RECEIVER_DUNS_NUMBER + '</udt:DUNS>
					</upi:PartnerIdentification>
				</ssdh:Receiver>
				<ssdh:Sender>
					<ssdh:BusinessServiceInformation>
					<ssdh:ActionName>Request</ssdh:ActionName>
					<ssdh:ProcessIdentifier>3B2 - Ready to Ship (V11.02.00)</ssdh:ProcessIdentifier>
					<ssdh:ServiceName>3B2 Ready to Ship</ssdh:ServiceName>
					</ssdh:BusinessServiceInformation>
					<upi:PartnerIdentification>
					<udt:DUNS>' + A.SENDER_DUNS_NUMBER + '</udt:DUNS>
					</upi:PartnerIdentification>
				</ssdh:Sender>
				</ssdh:DocumentHeader>
			</AdvanceShipmentNotification>
			'	
		FROM #OTM_3B2RTS_MAIN A, #OTM_3B2RTS_MAPPING B;

		BEGIN TRANSACTION OTM_3B2RTS_OUT; 

		UPDATE 
			[dbo].[OTM_3B2RTS_MAIN] 
		SET
			SENDFLAG ='S', 
			FILE_NAME = 'IRTS-' + MESSAGE_ID + '-0-' + SITE_NAME + '-' + SENDER_DUNS_NUMBER + '-' + FORMAT(GETDATE(), 'MMddyyHHmmss') + '.xml', 
			LASTEDITDT = FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss') 
		WHERE MESSAGE_ID = @Messageid; 

		INSERT INTO [dbo].[TB_B2B_FILE]
			(F_PLANT, F_DOCID, F_TYPE, F_INOUT, F_FILENAME, F_DOC, F_DOCTYPE, F_DOCTIMESTAMP) 
		SELECT 'BTS', MESSAGE_ID, '3B2RTS', 'OUT', FILE_NAME, CONVERT(VARBINARY(MAX), @doc), 'XML', FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss') 
		FROM OTM_3B2RTS_MAIN  
		WHERE MESSAGE_ID = @Messageid; 

		COMMIT TRANSACTION OTM_3B2RTS_OUT; 
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION OTM_3B2RTS_OUT; 

		INSERT INTO OMS_SEND_MAIL(SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
		SELECT 'zhi-jie.chen@mail.foxconn.com', NULL, 'Generate 3B2RTS file error. MESSAGE_ID: ' + @Messageid + '. [dbo].[OTM_3B2RTS_OUT]', ERROR_MESSAGE(), 'System_Alter.txt';

		RETURN; 
	END CATCH
	
END
