USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B2SC_ALL]    Script Date: 2025/4/9 �W�� 09:26:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Zhi-jie
-- Create date: 2025-02-14
-- Description:	Generate all 3B2SC files
-- =============================================
ALTER PROCEDURE [dbo].[OTM_3B2SC_ALL]
AS
BEGIN
	DECLARE @TotalRows AS INT, @CurrentRowID AS INT = 1, --Loop
			@MESSAGE_ID AS VARCHAR(30); 
	
	IF OBJECT_ID('tempdb..#MESSAGEID_LIST') IS NOT NULL
		DROP TABLE #MESSAGEID_LIST; 

	SELECT 
		ROW_NUMBER() OVER(ORDER BY MESSAGE_ID) AS ROW_ID, 
		MESSAGE_ID 
	INTO #MESSAGEID_LIST 
	FROM [dbo].[OTM_3B2_MAIN] WHERE SENDFLAG = 'Y'; 
	
	SELECT @TotalRows = COUNT(*) FROM #MESSAGEID_LIST; 

	WHILE @CurrentRowID <= @TotalRows
	BEGIN
		SELECT @MESSAGE_ID = MESSAGE_ID FROM #MESSAGEID_LIST WHERE ROW_ID = @CurrentRowID; 

		EXEC [dbo].[OTM_3B2SC_OUT] @Messageid = @MESSAGE_ID; 

		SET @CurrentRowID = @CurrentRowID + 1; 
	END
END
