USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B18_PARSE]    Script Date: 2025/4/9 �W�� 09:25:45 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Zhi-jie
-- Create date: 2024-12-10
-- Description:	Parse 3B18
-- =============================================

ALTER PROCEDURE [dbo].[OTM_3B18_PARSE] 
	@DOCID VARCHAR(50)
AS
BEGIN
	DECLARE @doc AS XML, @FILE_NAME AS VARCHAR(100), @ERROR_MESSAGE AS VARCHAR(100), @ERROR_CODE AS VARCHAR(100), @HasError AS INT = 0;
	
	BEGIN TRY
		SELECT @doc = CONVERT(XML, F_DOC), @FILE_NAME = F_FILENAME FROM [dbo].[TB_B2B_FILE] WHERE F_DOCID = @DOCID AND F_STATUS = 0; 

		IF OBJECT_ID('tempdb..#OTM_3B18_MAIN') IS NOT NULL
			DROP TABLE #OTM_3B18_MAIN;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@FILE_NAME AS FILE_NAME, 
			@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS PLANT,
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:Creation)[1]','varchar(50)') AS TRANSMISSION_DATE,
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Type)[1]','varchar(50)') AS TRANSACTION_TYPE,
			@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/upi:PartnerName)[1]','varchar(50)') AS RECEIVER_NAME,
			@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS RECEIVER_DUNS_NUMBER,
			@doc.value('(//ssdh:DocumentHeader/ssdh:Sender/upi:PartnerIdentification/upi:PartnerName)[1]','varchar(50)') AS SENDER_NAME,
			@doc.value('(//ssdh:DocumentHeader/ssdh:Sender/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS SENDER_DUNS_NUMBER,
			A.B.value('(dat:ActionType)[1]','varchar(50)') AS ACTION_TYPE,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument/udc:DateTime)[1]','varchar(50)') AS ORDER_DATE,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Identifier)[1]','varchar(50)') AS ORDER_NUMBER,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument[udct:DocumentType = "DOR"]/udc:Identifier)[1]','varchar(50)') AS DELIVERY_ID,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Revision)[1]','varchar(50)') AS ORDER_TYPE_NAME,
			A.B.value('(tns:HeaderInformation/tns:ShippingOrderInformation/dl:OrderInformation/dl:OrderReference/udc:Identifier)[1]','varchar(50)') AS CUST_PO_NUMBER,
			A.B.value('(tns:HeaderInformation/tns:ShippingOrderInformation/dl:OrderInformation/dl:OrderReference/udc:Revision)[1]','varchar(50)') AS REVISION_NUMBER,
			A.B.value('(tns:HeaderInformation/tns:ShippingOrderInformation/dl:OrderInformation/dl:TotalAmount/ume:Amount)[1]','varchar(50)') AS ORDER_TOTAL,
			A.B.value('(tns:HeaderInformation/tns:ShippingOrderInformation/dl:OrderInformation/dl:TotalAmount/ucr:Currency)[1]','varchar(50)') AS CURRENCY_CODE,
			A.B.value('(tns:ShipmentInformation/tns:ContainerTotalCount)[1]','varchar(50)') AS CARTON_COUNT,
			A.B.value('(tns:ShipmentInformation/dl:DateInformation/dl:ActualShipDate)[1]','varchar(50)') AS SHIP_DATE,
			A.B.value('(tns:ShipmentInformation/dl:DateInformation/dl:RequestedShipDate/dl:ShipDate)[1]','varchar(50)') AS SHIP_END_DATE,
			A.B.value('(tns:ShipmentInformation/tns:FreightTotalPhysicalDimension/dl:MassPhysicalDimension/upd:Weight/upd:Value)[1]','varchar(50)') AS TOTAL_WEIGHT,
			A.B.value('(tns:ShipmentInformation/dl:FreightValuation/dl:DeclaredValue/ume:FinancialAmount/ume:Amount)[1]','varchar(50)') AS FREIGHT_CHARGE,
			A.B.value('(tns:ShipmentInformation/tns:IsInsuranceRequired)[1]','varchar(50)') AS INSURANCE_REQUIRED,
			A.B.value('(tns:ShipmentInformation/tns:IsIntraCompanyTransfer)[1]','varchar(50)') AS INTRA_COMPANY_TRANSFER_FLAG,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Line)[1]','varchar(50)') AS ORDER_LINE_NUMBER,
			A.B.value('(tns:HeaderInformation/tns:ShippingDocument[udct:DocumentType = "DOR"]/udc:Line)[1]','varchar(50)') AS ORDER_RELEASE_NUMBER,
			A.B.value('(tns:HeaderInformation/tns:ShippingOrderInformation/tns:RequestingOrderInformation/tns:OrderReference/udc:Identifier)[1]','varchar(50)') AS TRIP_ID,
			A.B.value('(tns:ShipmentLineItem/sha:QuantityInformation/sha:ShippedQuantity)[1]','int') AS SHIPPED_QUANTITY,
			A.B.value('(tns:ShipmentLineItem/udc:BusinessDocumentReference/udc:Line)[1]','varchar(50)') AS SHIPMENT_ID
		INTO #OTM_3B18_MAIN
		FROM @doc.nodes('//tns:ShippingBusinessDocument') A(B);

		UPDATE 
			#OTM_3B18_MAIN 
		SET 
			PLANT = CASE PLANT WHEN '544734668' THEN 'FOL' WHEN '556698977' THEN 'FVN' WHEN '659259449' THEN 'FGP' ELSE '' END, 
			TRANSMISSION_DATE = DATEADD(HOUR, 8, CONVERT(VARCHAR(19), SWITCHOFFSET(CAST(TRANSMISSION_DATE AS DATETIMEOFFSET), '+00:00'), 120)), 
			SHIP_DATE = DATEADD(HOUR, 8, CONVERT(VARCHAR(19), SWITCHOFFSET(CAST(SHIP_DATE AS DATETIMEOFFSET), '+00:00'), 120)), 
			SHIP_END_DATE = DATEADD(HOUR, 8, CONVERT(VARCHAR(19), SWITCHOFFSET(CAST(SHIP_END_DATE AS DATETIMEOFFSET), '+00:00'), 120));


		IF OBJECT_ID('tempdb..#OTM_3B18_REQUESTINGORDER') IS NOT NULL
			DROP TABLE #OTM_3B18_REQUESTINGORDER;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			A.B.value('(udc:BusinessDocumentReference/udc:Identifier)[1]','varchar(50)') AS ORDER_RELEASE_NAME,
			A.B.value('(tns:IsOrderToBeMerged)[1]','varchar(50)') AS MERGE_FLAG,
			A.B.value('(tns:OrderReference/udc:DateTime)[1]','varchar(50)') AS SHIP_DATE,
			A.B.value('(tns:OrderReference/udc:Line)[1]','varchar(50)') AS SHIPSET_COUNT,
			A.B.value('(tns:OrderReference/udc:Revision)[1]','varchar(50)') AS SHIPSET_SEQUENCE,
			A.B.value('(tns:OrderReference/udc:SubLine)[1]','varchar(50)') AS HEADER_SEQ,
			A.B.value('(tns:OrderReference/udc:Identifier)[1]','varchar(50)') AS TRIP_ID,
			A.B.value('(tns:OrderReference/udct:DocumentType)[1]','varchar(50)') AS SHIPPING_TYPE
		INTO #OTM_3B18_REQUESTINGORDER
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:HeaderInformation/tns:ShippingOrderInformation/tns:RequestingOrderInformation') A(B);


		IF OBJECT_ID('tempdb..#OTM_3B18_ITEM') IS NOT NULL
			DROP TABLE #OTM_3B18_ITEM;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			A.B.value('(upi:FullPartner/ulc:Location/ulc:AlternativeIdentifier/ulc:Identifier)[1]','varchar(50)') AS DOCUMENT_IDENTIFIER,
			A.B.value('(upi:FullPartner/upi:PartnerIdentification/upi:PartnerName)[1]','varchar(50)') AS NAME,
			A.B.value('(upi:FullPartner/upi:PartnerIdentification/ulc:AlternativeIdentifier/ulc:Identifier)[1]','varchar(50)') AS ALTERNATE_IDENTIFIER,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:AddressLine1)[1]','varchar(200)') AS ADDRESS_LINE1,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:AddressLine2)[1]','varchar(200)') AS ADDRESS_LINE2,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:AddressLine3)[1]','varchar(200)') AS ADDRESS_LINE3,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:AddressLine4)[1]','varchar(200)') AS ADDRESS_LINE4,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:AddressLine5)[1]','varchar(200)') AS ADDRESS_LINE5,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:CityName)[1]','varchar(50)') AS CITY,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/uc:Country)[1]','varchar(50)') AS COUNTRY,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ucs:CountrySubdivision)[1]','varchar(50)') AS STATE,
			A.B.value('(upi:FullPartner/ulc:PhysicalAddress/ulc:PostalCode)[1]','varchar(50)') AS ZIP,
			A.B.value('(upi:FullPartner/upri:ProcessRoleIdentifier)[1]','varchar(50)') AS ROLE_IDENTIFIER
		INTO #OTM_3B18_ITEM
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:ShipmentInformation/tns:DeclarationInformation/upi:PartnerDescription') A(B);


		IF OBJECT_ID('tempdb..#OTM_3B18_INSTRUCTIONS') IS NOT NULL
			DROP TABLE #OTM_3B18_INSTRUCTIONS;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			A.B.value('(dl:Notes)[1]','varchar(50)') AS NOTES,
			A.B.value('(dl:ShippingInstructionsCode)[1]','varchar(50)') AS TYPE
		INTO #OTM_3B18_INSTRUCTIONS
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:ShipmentInformation/dl:Instructions') A(B);


		IF OBJECT_ID('tempdb..#OTM_3B18_ROUTINGINFO') IS NOT NULL
			DROP TABLE #OTM_3B18_ROUTINGINFO;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			A.B.value('(upi:PartnerDescription/upi:KnownPartnerContact/upi:KnownPartner/upi:PartnerIdentification/ulc:AlternativeIdentifier[ulc:Authority = "National Motor Freight Traffic Association"]/ulc:Identifier)[1]','varchar(50)') AS SCAC_CODE,
			A.B.value('(upi:PartnerDescription/upi:KnownPartnerContact/upi:KnownPartner/upi:PartnerIdentification/ulc:AlternativeIdentifier[ulc:Authority = "Cisco Systems"]/ulc:Identifier)[1]','varchar(50)') AS SHIP_VIA,
			A.B.value('(upi:PartnerDescription/upi:KnownPartnerContact/upi:KnownPartner/upi:PartnerIdentification/ulc:AlternativeIdentifier[ulc:Authority = "Shipping Preference"]/ulc:Identifier)[1]','varchar(50)') AS SHIPPING_PREFERENCE,
			A.B.value('(tns:SequenceNumber)[1]','varchar(50)') AS HEADER_SEQ,
			A.B.value('(rssl:ShippingServiceLevel)[1]','varchar(50)') AS SERVICE_LEVEL,
			A.B.value('(dp:SpecialHandlingInstruction/dp:Text)[1]','varchar(50)') AS DESTINATION_AIRPORT
		INTO #OTM_3B18_ROUTINGINFO
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:ShipmentInformation/tns:RoutingInformation') A(B);


		IF OBJECT_ID('tempdb..#OTM_3B18_LINE') IS NOT NULL
			DROP TABLE #OTM_3B18_LINE;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/udc:BusinessDocumentReference/udct:DocumentType)[1]','varchar(50)') AS DOCUMENT_TYPE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/udc:BusinessDocumentReference/udc:Identifier)[1]','varchar(50)') AS LINE_ITEM_TYPE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:LineNumber)[1]','varchar(50)') AS LINE_NUMBER,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:PricingInformation/sha:MonetaryAmount[rat:AmountType = "UNI"]/ume:FinancialAmount/ume:Amount)[1]','varchar(50)') AS UNI_PRICE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:PricingInformation/sha:MonetaryAmount[rat:AmountType = "TOV"]/ume:FinancialAmount/ume:Amount)[1]','varchar(50)') AS TOV_PRICE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:PricingInformation/sha:MonetaryAmount[rat:AmountType = "VAD"]/ume:FinancialAmount/ume:Amount)[1]','varchar(50)') AS VAD_PRICE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:PricingInformation/sha:MonetaryAmount[rat:AmountType = "UNI"]/ume:FinancialAmount/ucr:Currency)[1]','varchar(50)') AS CURRENCY_CODE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:ProductDescription/updi:Primary)[1]','varchar(200)') AS CISCO_PART_DESCRIPTION,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:ProductIdentificationInformation/updi:ProductName)[1]','varchar(50)') AS CISCO_PART_NUMBER,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/sha:QuantityInformation/sha:RequestedQuantity)[1]','varchar(50)') AS ORDERED_QUANTITY,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Height/upd:UnitOfMeasure)[1]','varchar(50)') AS DIM_HEIGHT_UOM,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Height/upd:Value)[1]','varchar(50)') AS CARTON_HEIGHT,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Length/upd:UnitOfMeasure)[1]','varchar(50)') AS DIM_LENGTH_UOM,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Length/upd:Value)[1]','varchar(50)') AS CARTON_LENGTH,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Width/upd:UnitOfMeasure)[1]','varchar(50)') AS DIM_WIDTH_UOM,
			A.B.value('(tns:ContainerPhysicalDimension/dl:Linear/dl:Width/upd:Value)[1]','varchar(50)') AS CARTON_WIDTH,
			A.B.value('(tns:ContainerPhysicalDimension/dl:MassPhysicalDimension/upd:Volume/upd:UnitOfMeasure)[1]','varchar(50)') AS HANDLING_UNIT_VOLUME_UOM,
			A.B.value('(tns:ContainerPhysicalDimension/dl:MassPhysicalDimension/upd:Volume/upd:Value)[1]','varchar(50)') AS HANDLING_UNIT_VOLUME,
			A.B.value('(tns:ContainerPhysicalDimension/dl:MassPhysicalDimension/upd:Weight/upd:UnitOfMeasure)[1]','varchar(50)') AS CARTON_WEIGHT_UOM,
			A.B.value('(tns:ContainerPhysicalDimension/dl:MassPhysicalDimension/upd:Weight/upd:Value)[1]','varchar(50)') AS CARTON_GROSS_WEIGHT,
			A.B.value('(tns:Identifier)[1]','varchar(50)') AS CARTON_NUMBER,
			A.B.value('(tns:ShippingCartonIdentifier)[1]','varchar(50)') AS PARENT_CARTON_NUMBER,
			A.B.value('(tns:ShippingContainerItem/dl:ManufacturerProfile/dl:CountryOfOrigin)[1]','varchar(50)') AS COUNTRY_OF_ORIGIN,
			A.B.value('(tns:ShippingContainerItem/dl:ManufacturerProfile/dl:ProductSerialIdentifier)[1]','varchar(50)') AS SERIAL_NUMBER,
			A.B.value('(tns:ShippingContainerItem/tns:NumberOfItemPackages)[1]','varchar(50)') AS PACKED_QUANTITY,
			A.B.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/uuom:UnitOfMeasure)[1]','varchar(50)') AS UOM
		INTO #OTM_3B18_LINE
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:ShippingContainer') A(B);


		IF OBJECT_ID('tempdb..#OTM_3B18_CROSSREF') IS NOT NULL
			DROP TABLE #OTM_3B18_CROSSREF;

		;with xmlnamespaces(
			default 'http://xyz/',
			'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
			'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
			'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
			'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
			'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
			'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
			'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
			'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
			'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
			'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
			'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
			'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
			'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
			'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
			'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
			'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
			'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
			'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
			'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
			'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
			'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
			'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
			'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
			'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
			'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
			'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
			'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
			'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
			'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
			'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
			'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
			'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
			'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
			'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
			'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
		)
		SELECT 
			@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS MESSAGE_ID,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:LineNumber)[1]','varchar(50)') AS LINE_NUMBER,
			@doc.value('(//tns:ShipmentLineItem/tns:ProductIdentificationInformation/ulc:AlternativeIdentifier/ulc:Authority)[1]','varchar(50)') AS ITEM_CROSS_REFERENCE_TYPE,
			@doc.value('(//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:ProductIdentificationInformation/ulc:AlternativeIdentifier/ulc:Identifier)[1]','varchar(50)') AS ITEM_CROSS_REFERENCE
		INTO #OTM_3B18_CROSSREF
		FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:ShipmentLineItem/tns:ProductIdentificationInformation/ulc:AlternativeIdentifier') A(B);


		--Check data
		IF EXISTS (SELECT 1 FROM #OTM_3B18_MAIN WHERE (TRIP_ID = '' OR TRIP_ID IS NULL) AND ACTION_TYPE != 'DEL') AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing Load ID/Trip Id', @ERROR_CODE = '3B18-INB0001', @HasError = 1;
		END

		IF EXISTS (SELECT 1 FROM #OTM_3B18_MAIN WHERE DELIVERY_ID = '' OR DELIVERY_ID IS NULL) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing deliveryID', @ERROR_CODE = '3B18-INB0002', @HasError = 1;
		END

		IF EXISTS (SELECT 1 FROM #OTM_3B18_MAIN A JOIN #OTM_3B18_ROUTINGINFO B ON A.MESSAGE_ID = B.MESSAGE_ID WHERE A.ACTION_TYPE != 'DEL' AND (B.SCAC_CODE = '' OR B.SCAC_CODE IS NULL)) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing CarrierCode', @ERROR_CODE = '3B18-INB0003', @HasError = 1;
		END

		IF EXISTS (SELECT 1 FROM #OTM_3B18_MAIN WHERE TRANSACTION_TYPE = '' OR TRANSACTION_TYPE IS NULL) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing TracsactionType', @ERROR_CODE = '3B18-INB0004', @HasError = 1;
		END

		IF EXISTS (
			SELECT 1 FROM #OTM_3B18_MAIN WHERE CUST_PO_NUMBER = '' OR CUST_PO_NUMBER IS NULL 
			UNION SELECT 1 FROM #OTM_3B18_CROSSREF WHERE LINE_NUMBER = '' OR LINE_NUMBER IS NULL OR ITEM_CROSS_REFERENCE = '' OR ITEM_CROSS_REFERENCE IS NULL) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing PO/ITEM/LINE/PN', @ERROR_CODE = '3B18-INB0005', @HasError = 1;
		END

		IF EXISTS (SELECT 1 FROM #OTM_3B18_MAIN WHERE SHIPPED_QUANTITY = '' OR SHIPPED_QUANTITY IS NULL) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Missing shippingQty', @ERROR_CODE = '3B18-INB0006', @HasError = 1;
		END

		IF NOT EXISTS (
			SELECT 1 
			FROM 
				OTM_3B2RTS_MAIN A 
				JOIN #OTM_3B18_MAIN B ON A.SHIPMENT_ID = B.SHIPMENT_ID 
				JOIN #OTM_3B18_CROSSREF C ON B.MESSAGE_ID = C.MESSAGE_ID 
			WHERE 
				A.PO_NUMBER = B.CUST_PO_NUMBER 
				AND (A.PO_LINE_NUMBER = C.LINE_NUMBER OR A.ITEM_NUMBER = C.LINE_NUMBER) 
				AND A.INVENTORY_ITEM_NUMBER = C.ITEM_CROSS_REFERENCE
		) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Invalid PO/ITEM/LINE/PN', @ERROR_CODE = '3B18-INB0009', @HasError = 1;
		END

		IF NOT EXISTS (
			SELECT 1 
			FROM 
				OTM_3B2RTS_MAIN A 
				JOIN #OTM_3B18_MAIN B ON A.SHIPMENT_ID = B.SHIPMENT_ID 
				JOIN #OTM_3B18_CROSSREF C ON B.MESSAGE_ID = C.MESSAGE_ID 
			WHERE 
				A.PO_NUMBER = B.CUST_PO_NUMBER 
				AND A.SHIPPED_QUANTITY = B.SHIPPED_QUANTITY 
				AND (A.PO_LINE_NUMBER = C.LINE_NUMBER OR A.ITEM_NUMBER = C.LINE_NUMBER) 
				AND A.INVENTORY_ITEM_NUMBER = C.ITEM_CROSS_REFERENCE
		) AND @HasError = 0
		BEGIN
			SELECT @ERROR_MESSAGE = 'Invalid shippingQty', @ERROR_CODE = '3B18-INB0010', @HasError = 1;
		END

		BEGIN TRANSACTION OTM_3B18_PARSE; 

		--Insert data
		IF @HasError = 1
		BEGIN
			IF OBJECT_ID('tempdb..#OTM_FA_TO_CISCO') IS NOT NULL
				DROP TABLE #OTM_FA_TO_CISCO;

			;with xmlnamespaces(
				default 'http://xyz/',
				'urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23' AS ssdh,
				'http://www.tibco.com/xmlns/ae2xsd/2002/05/ae/ADB/OTMflex' AS pfx24,
				'urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03' AS ucr,
				'urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04' AS uci,
				'urn:rosettanet:specification:universal:Document:xsd:schema:01.12' AS udc,
				'urn:rosettanet:specification:domain:Procurement:xsd:schema:02.28' AS dp,
				'urn:rosettanet:specification:domain:Shared:xsd:schema:01.17' AS sha,
				'urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04' AS updi,
				'urn:rosettanet:specification:universal:DataType:xsd:schema:01.04' AS udt,
				'urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04' AS dsh,
				'urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03' AS dfpt,
				'urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16' AS upi,
				'urn:rosettanet:specification:domain:Shared:AmountType:xsd:codelist:01.03' AS rat,
				'urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03' AS dsdc,
				'urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02' AS ucs,
				'urn:rosettanet:specification:domain:Procurement:ActionType:xsd:codelist:01.04' AS dat,
				'urn:rosettanet:specification:universal:Country:xsd:codelist:01.02' AS uc,
				'http://www.w3.org/2001/XMLSchema-instance' AS xsi,
				'urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04' AS uuom,
				'urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22' AS dl,
				'urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03' AS drl,
				'urn:rosettanet:specification:universal:Locations:xsd:schema:01.04' AS ulc,
				'urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03' AS dic,
				'urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01' AS rpkt,
				'urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11' AS upri,
				'urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05' AS dsm,
				'urn:rosettanet:specification:interchange:ShippingDocumentationNotification:xsd:schema:02.07' AS tns,
				'urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02' AS dsd,
				'urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06' AS ume,
				'urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03' AS dcst,
				'urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13' AS udct,
				'urn:rosettanet:specification:domain:Procurement:PaymentTerms:xsd:codelist:01.04' AS dpts,
				'urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06' AS dtrt,
				'urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07' AS upd,
				'urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01' AS rssl
			)
			SELECT 
				'3B18C' AS DOCTYPE,
				@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS PLANT,
				A.B.value('(tns:ShippingOrderInformation/tns:RequestingOrderInformation/tns:OrderReference/udc:Identifier)[1]','varchar(50)') AS TRIP_ID,
				A.B.value('(tns:ShippingDocument[udct:DocumentType = "DOR"]/udc:Identifier)[1]','varchar(50)') AS DELIVERY_ID,
				@doc.value('(//ssdh:DocumentHeader/ssdh:DocumentInformation/ssdh:DocumentIdentification/ssdh:Identifier)[1]','varchar(50)') AS REQUEST_MESSAGE_ID,
				FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss') AS TRANSMISSION_DATE,
				RIGHT(REPLICATE('0', 15) + CAST(NEXT VALUE FOR dbo.MessageID_Seq AS VARCHAR(30)), 15) AS MESSAGE_ID,
				'3B18' AS MESSAGE_TYPE,
				@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS SENDER_DUNS_NUMBER,
				A.B.value('(tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Identifier)[1]','varchar(50)') AS PO_NUMBER,
				A.B.value('(tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Line)[1]','varchar(50)') AS PO_LINE_NUMBER,
				A.B.value('(tns:ShippingDocument[udct:DocumentType = "PUO"]/udc:Revision)[1]','varchar(50)') AS VERSION_NO,
				@ERROR_CODE AS ERROR_CODE,
				@ERROR_MESSAGE AS ERROR_MESSAGE,
				@doc.value('(//ssdh:DocumentHeader/ssdh:Receiver/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS SENDER_NAME,
				'Cisco' AS RECEIVER_NAME,
				@doc.value('(//ssdh:DocumentHeader/ssdh:Sender/upi:PartnerIdentification/udt:DUNS)[1]','varchar(50)') AS RECEIVER_DUNS_NUMBER
			INTO #OTM_FA_TO_CISCO
			FROM @doc.nodes('//tns:ShippingBusinessDocument/tns:HeaderInformation') A(B);
	
			UPDATE 
				#OTM_FA_TO_CISCO
			SET 
				PLANT = CASE 
							WHEN PLANT = '544734668' THEN 'FOC' 
							WHEN PLANT = '556698977' THEN 'FVN' 
							WHEN PLANT = '659259449' THEN 'FGP' 
						END,
				SENDER_NAME = CASE 
								WHEN SENDER_NAME = '544734668' THEN 'FOXCONN CHINA' 
								WHEN SENDER_NAME = '556698977' THEN 'FOXCONN VIETNAM' 
								WHEN SENDER_NAME = '659259449' THEN 'FOXCONN MEXICO' 
							END;

			INSERT INTO OTM_FA_TO_CISCO
				(DOCTYPE, PLANT, TRIP_ID, DELIVERY_ID, REQUEST_MESSAGE_ID, TRANSMISSION_DATE, MESSAGE_ID, MESSAGE_TYPE, SENDER_DUNS_NUMBER, PO_NUMBER, PO_LINE_NUMBER, 
				VERSION_NO, ERROR_CODE, ERROR_MESSAGE, SENDER_NAME, RECEIVER_NAME, RECEIVER_DUNS_NUMBER)
			SELECT * FROM #OTM_FA_TO_CISCO;
		END

		IF @HasError = 0
		BEGIN
			INSERT INTO OTM_3B18_MAIN
				(FILE_NAME, PLANT, MESSAGE_ID, TRANSMISSION_DATE, TRANSACTION_TYPE, RECEIVER_NAME, RECEIVER_DUNS_NUMBER, SENDER_NAME, SENDER_DUNS_NUMBER, ACTION_TYPE, ORDER_DATE, ORDER_NUMBER, 
				DELIVERY_ID, ORDER_TYPE_NAME, CUST_PO_NUMBER, REVISION_NUMBER, ORDER_TOTAL, CURRENCY_CODE, CARTON_COUNT, SHIP_DATE, SHIP_END_DATE, TOTAL_WEIGHT, FREIGHT_CHARGE, 
				INSURANCE_REQUIRED, INTRA_COMPANY_TRANSFER_FLAG, ORDER_LINE_NUMBER, ORDER_RELEASE_NUMBER, TRIP_ID, SHIPPED_QUANTITY, SHIPMENT_ID) 
			SELECT * FROM #OTM_3B18_MAIN;

			INSERT INTO OTM_3B18_REQUESTINGORDER
				(MESSAGE_ID, ORDER_RELEASE_NAME, MERGE_FLAG, SHIP_DATE, SHIPSET_COUNT, SHIPSET_SEQUENCE, HEADER_SEQ, TRIP_ID, SHIPPING_TYPE) 
			SELECT * FROM #OTM_3B18_REQUESTINGORDER;

			INSERT INTO OTM_3B18_ITEM
				(MESSAGE_ID, DOCUMENT_IDENTIFIER, NAME, ALTERNATE_IDENTIFIER, ADDRESS_LINE1, ADDRESS_LINE2, ADDRESS_LINE3, ADDRESS_LINE4, ADDRESS_LINE5, CITY, COUNTRY, STATE, ZIP, ROLE_IDENTIFIER) 
			SELECT * FROM #OTM_3B18_ITEM;
			
			INSERT INTO OTM_3B18_INSTRUCTIONS
				(MESSAGE_ID, NOTES, TYPE) 
			SELECT * FROM #OTM_3B18_INSTRUCTIONS;

			INSERT INTO OTM_3B18_ROUTINGINFO
				(MESSAGE_ID, SCAC_CODE, SHIP_VIA, SHIPPING_PREFERENCE, HEADER_SEQ, SERVICE_LEVEL, DESTINATION_AIRPORT) 
			SELECT * FROM #OTM_3B18_ROUTINGINFO;
			
			INSERT INTO OTM_3B18_LINE
				(MESSAGE_ID, DOCUMENT_TYPE, LINE_ITEM_TYPE, LINE_NUMBER, UNI_PRICE, TOV_PRICE, VAD_PRICE, CURRENCY_CODE, CISCO_PART_DESCRIPTION, CISCO_PART_NUMBER, ORDERED_QUANTITY, 
				DIM_HEIGHT_UOM, CARTON_HEIGHT, DIM_LENGTH_UOM, CARTON_LENGTH, DIM_WIDTH_UOM, CARTON_WIDTH, HANDLING_UNIT_VOLUME_UOM, HANDLING_UNIT_VOLUME, CARTON_WEIGHT_UOM, CARTON_GROSS_WEIGHT, 
				CARTON_NUMBER, PARENT_CARTON_NUMBER, COUNTRY_OF_ORIGIN, SERIAL_NUMBER, PACKED_QUANTITY, UOM) 
			SELECT * FROM #OTM_3B18_LINE;
			
			INSERT INTO OTM_3B18_CROSSREF
				(MESSAGE_ID, LINE_NUMBER, ITEM_CROSS_REFERENCE_TYPE, ITEM_CROSS_REFERENCE)
			SELECT * FROM #OTM_3B18_CROSSREF;			
		END

		UPDATE [dbo].[TB_B2B_FILE] SET F_STATUS = 1 WHERE F_DOCID = @DOCID; 
		
		COMMIT TRANSACTION OTM_3B18_PARSE; 
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION OTM_3B18_PARSE; 

		INSERT INTO [dbo].[OMS_SEND_MAIL](SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
		SELECT 'zhi-jie.chen@mail.foxconn.com', NULL, 'Parse 3B18 error. DOCID: ' + @DOCID + '. [dbo].[OTM_3B18_PARSE]', ERROR_MESSAGE(), 'System_Alter.txt'; 

		RETURN; 
	END CATCH
END
