USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_FA_PARSE]    Script Date: 2025/4/9 �W�� 09:27:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Zhi-jie
-- Create date: 2024-12-23
-- Description:	Parsing Cisco FA data
-- =============================================
ALTER PROCEDURE [dbo].[OTM_FA_PARSE] 
	@DOCID VARCHAR(50)
AS
BEGIN
	DECLARE @doc AS XML, @filename AS VARCHAR(100); 

	BEGIN TRY
		SELECT @doc = CONVERT(XML, F_DOC), @filename = F_FILENAME FROM [dbo].[TB_B2B_FILE] WHERE F_DOCID = @DOCID;

		IF OBJECT_ID('tempdb..#OTM_FA_FROM_CISCO_MAIN') IS NOT NULL
			DROP TABLE #OTM_FA_FROM_CISCO_MAIN;

		SELECT 
			@filename AS FILE_NAME,
			A.B.value('(DocumentHeader/CorrelationInformation/RequestingDocumentInformation/RequestingDocumentInstanceIdentifier)[1]','varchar(50)') AS PLANT,
			A.B.value('(DocumentHeader/DocumentInformation/Creation)[1]','varchar(50)') AS TRANSMISSION_DATE,
			A.B.value('(DocumentHeader/Receiver/PartnerIdentification/Name)[1]','varchar(50)') AS RECEIVER_NAME,
			A.B.value('(DocumentHeader/Receiver/PartnerIdentification/AlternativeIdentifier/Identifier)[1]','varchar(50)') AS RECEIVER_DUNS_NUMBER,
			A.B.value('(DocumentHeader/Sender/PartnerIdentification/Name)[1]','varchar(50)') AS SENDER_NAME,
			A.B.value('(DocumentHeader/Sender/PartnerIdentification/AlternativeIdentifier/Identifier)[1]','varchar(50)') AS SENDER_DUNS_NUMBER,
			A.B.value('(ActionControl/MessageTrackingIdentification)[1]','varchar(50)') AS REFERENCE_MESSAGE_ID,
			A.B.value('(ProcessIdentity/GlobalProcessIndicatorCode)[1]','varchar(50)') AS MESSAGE_TYPE,
			A.B.value('(ProcessIdentity/InstanceIdentifier)[1]','varchar(50)') AS MESSAGE_ID,
			A.B.value('(ProcessStatus/Status)[1]','varchar(50)') AS ACK_STATUS,
			A.B.value('(ProcessStatus/ReasonCode)[1]','varchar(50)') AS ERROR_CODE,
			A.B.value('(ProcessStatus/ReasonDescription)[1]','varchar(100)') AS ERROR_DESC,
			A.B.value('(DocumentGenerationDateTime/DateTimeStamp)[1]','varchar(50)') AS ACK_DATE,
			@doc.value('(//FunctionalAcknowledgement[ProcessIdentity/GlobalProcessIndicatorCode = "3B2SCINB-FA"]/DocumentIdentifier/ProprietaryDocumentIdentifier)[1]','varchar(50)') AS DELIVERY_ID,
			@doc.value('(//FunctionalAcknowledgement[ProcessIdentity/GlobalProcessIndicatorCode = "3B2RTS-FA"]/DocumentIdentifier/ProprietaryDocumentIdentifier)[1]','varchar(50)') AS PO_NUMBER,
			FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss') AS CREATEDT
		INTO #OTM_FA_FROM_CISCO_MAIN
		FROM @doc.nodes('//FunctionalAcknowledgement') A(B);

		BEGIN TRANSACTION OTM_FA_PARSE;

		UPDATE 
			#OTM_FA_FROM_CISCO_MAIN 
		SET 
			TRANSMISSION_DATE = CONVERT(VARCHAR(19), SWITCHOFFSET(CAST(TRANSMISSION_DATE AS DATETIMEOFFSET), '+00:00'), 120),
			ACK_DATE = CONVERT(VARCHAR(19), SWITCHOFFSET(CAST(ACK_DATE AS DATETIMEOFFSET), '+00:00'), 120);

		INSERT INTO OTM_FA_FROM_CISCO_MAIN
			(FILE_NAME, PLANT, TRANSMISSION_DATE, RECEIVER_NAME, RECEIVER_DUNS_NUMBER, SENDER_NAME, SENDER_DUNS_NUMBER, REFERENCE_MESSAGE_ID, MESSAGE_TYPE, MESSAGE_ID, 
			ACK_STATUS, ERROR_CODE, ERROR_DESC, ACK_DATE, DELIVERY_ID, PO_NUMBER, CREATEDT)
		SELECT * FROM #OTM_FA_FROM_CISCO_MAIN;

		UPDATE [dbo].[TB_B2B_FILE] SET F_STATUS = 1 WHERE F_DOCID = @DOCID;

		COMMIT TRANSACTION OTM_FA_PARSE;
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION OTM_FA_PARSE;

		INSERT INTO OMS_SEND_MAIL(SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
		SELECT 'zhi-jie.chen@mail.foxconn.com', NULL, 'Parse Cisco FA data failed. [dbo].[OTM_FA_PARSE]', ERROR_MESSAGE(), 'System_Alter.txt';

		RETURN;
	END CATCH

END
