USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B2SC_OUT]    Script Date: 2025/4/9 �W�� 09:27:14 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Zhi-jie
-- Create date: 2024-12-30
-- Description:	Generate 3B2SC
-- =============================================
ALTER PROCEDURE [dbo].[OTM_3B2SC_OUT]
	@Messageid AS VARCHAR(30)
AS
BEGIN
	DECLARE @doc AS XML, @SubContainer AS NVARCHAR(MAX), 
			@Shipped_Quantity AS VARCHAR(10), @HAZARDOUS_MATERIAL AS VARCHAR(30), @INVENTORY_ITEM_NUMBER AS VARCHAR(30), @UOM AS VARCHAR(20), @TRACKING_NUMBER AS VARCHAR(50), 
			@ORDER_RELEASE_NUMBER AS VARCHAR(100); 

	BEGIN TRY
		IF OBJECT_ID('tempdb..#OTM_3B2_MAIN') IS NOT NULL
			DROP TABLE #OTM_3B2_MAIN;

		SELECT * INTO #OTM_3B2_MAIN FROM [dbo].[OTM_3B2_MAIN] WHERE MESSAGE_ID = @Messageid;

		IF OBJECT_ID('tempdb..#OTM_3B2SC_LINE') IS NOT NULL
			DROP TABLE #OTM_3B2SC_LINE;

		SELECT * INTO #OTM_3B2SC_LINE FROM [dbo].[OTM_3B2SC_LINE] WHERE MESSAGE_ID = @Messageid;

		IF OBJECT_ID('tempdb..#OTM_3B2_ITEM') IS NOT NULL
			DROP TABLE #OTM_3B2_ITEM;

		SELECT * INTO #OTM_3B2_ITEM FROM [dbo].[OTM_3B2_ITEM] A WHERE EXISTS (SELECT 1 FROM #OTM_3B2_MAIN B WHERE A.DELIVERY_ID = B.DELIVERY_ID);

		IF OBJECT_ID('tempdb..#OTM_3B2SC_MAPPING') IS NOT NULL
			DROP TABLE #OTM_3B2SC_MAPPING;

		SELECT * INTO #OTM_3B2SC_MAPPING FROM [dbo].[OTM_3B2SC_MAPPING] A WHERE EXISTS (SELECT 1 FROM #OTM_3B2_MAIN B WHERE A.SENDER_DUNS_NUMBER = B.SENDER_DUNS_NUMBER AND A.EXPEDITE_TYPE = B.EXPEDITE_TYPE);

		SELECT 
			@ORDER_RELEASE_NUMBER = CASE 
										WHEN ORDER_RELEASE_NUMBER IS NOT NULL AND ORDER_RELEASE_NUMBER != '' THEN '<udc:SubLine>' + ORDER_RELEASE_NUMBER + '</udc:SubLine>' 
										ELSE '' 
									END 
		FROM #OTM_3B2_MAIN; 

		SELECT 
			@Shipped_Quantity = SUM(CONVERT(INT, SHIPPED_QUANTITY)), 
			@HAZARDOUS_MATERIAL = MAX(HAZARDOUS_MATERIAL), 
			@INVENTORY_ITEM_NUMBER = MAX(INVENTORY_ITEM_NUMBER), 
			@UOM = MAX(UOM), 
			@TRACKING_NUMBER = MAX(TRACKING_NUMBER) 
		FROM #OTM_3B2SC_LINE; 

		IF EXISTS (SELECT 1 FROM #OTM_3B2SC_LINE A JOIN #OTM_3B2_MAIN B ON A.MESSAGE_ID = B.MESSAGE_ID 
					WHERE (A.TRACKING_NUMBER IS NULL OR TRACKING_NUMBER = '') AND B.SENDER_DUNS_NUMBER != '544734668' AND B.PLANT != 'SHKF') 
		BEGIN
			RETURN; 
		END

		SET @SubContainer = (
			SELECT 
				(
					SELECT '
					<SubContainer>
					  <ShippingContainer>
						<Identifier>' + AA.CARTON_NUMBER + '</Identifier>
						<upd:Linear>
						  <upd:Height>
							<upd:UnitOfMeasure>' + BB.CONTAINER_HEIGHT_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + BB.CONTAINER_HEIGHT + '</upd:Value>
						  </upd:Height>
						  <upd:Length>
							<upd:UnitOfMeasure>' + BB.CONTAINER_LENGTH_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + BB.CONTAINER_LENGTH + '</upd:Value>
						  </upd:Length>
						  <upd:Width>
							<upd:UnitOfMeasure>' + BB.CONTAINER_WIDTH_UOM + '</upd:UnitOfMeasure>
							<upd:Value>' + BB.CONTAINER_WIDTH + '</upd:Value>
						  </upd:Width>
						</upd:Linear>
						<dl:MassPhysicalDimension>
						  <upd:Weight>
							<upd:UnitOfMeasure>KIG</upd:UnitOfMeasure>
							<upd:Value>' + CAST(CAST((CAST(AA.SHIPPED_QUANTITY AS INT) * CAST(BB.MATERIAL_WEIGHT AS FLOAT) + BB.CONTAINER_WEIGHT) AS DECIMAL(18,3)) AS VARCHAR) + '</upd:Value>
						  </upd:Weight>
						</dl:MassPhysicalDimension>
					  </ShippingContainer>
					</SubContainer>
					'
					FROM #OTM_3B2SC_LINE AA 
					LEFT JOIN #OTM_3B2_ITEM BB ON AA.DELIVERY_ID = BB.DELIVERY_ID
					FOR XML PATH(''), TYPE
				).value('.', 'NVARCHAR(MAX)')
		);

		SELECT @doc = '<?xml version="1.0"?>
			<AdvanceShipmentNotification
				xmlns="urn:rosettanet:specification:interchange:AdvanceShipmentNotification:xsd:schema:02.04"
				xmlns:da="urn:rosettanet:specification:domain:Manufacturing:Axis:xsd:codelist:01.03"
				xmlns:dacc="urn:rosettanet:specification:domain:Procurement:AccountClassification:xsd:codelist:01.03"
				xmlns:dad="urn:rosettanet:specification:domain:Manufacturing:AttachmentDescription:xsd:codelist:01.03"
				xmlns:dbpq="urn:rosettanet:specification:domain:Procurement:BookPriceQualifier:xsd:codelist:01.04"
				xmlns:dccc="urn:rosettanet:specification:domain:Procurement:CreditCardClassification:xsd:codelist:01.03"
				xmlns:dcr="urn:rosettanet:specification:domain:Manufacturing:ChangeReason:xsd:codelist:01.04"
				xmlns:dcrt="urn:rosettanet:specification:domain:Procurement:CustomerType:xsd:codelist:01.03"
				xmlns:dcst="urn:rosettanet:specification:domain:Logistics:CustomsType:xsd:codelist:01.03"
				xmlns:ddpt="urn:rosettanet:specification:domain:Manufacturing:DevicePackageType:xsd:codelist:01.03"
				xmlns:det="urn:rosettanet:specification:domain:Manufacturing:EquipmentType:xsd:codelist:01.03"
				xmlns:dfe="urn:rosettanet:specification:domain:Procurement:ForecastEvent:xsd:codelist:01.03"
				xmlns:dfpt="urn:rosettanet:specification:domain:Logistics:FreightPaymentTerms:xsd:codelist:01.03"
				xmlns:dfrt="urn:rosettanet:specification:domain:Procurement:ForecastReferenceType:xsd:codelist:01.03"
				xmlns:dft="urn:rosettanet:specification:domain:Procurement:FinanceTerms:xsd:codelist:01.03"
				xmlns:dic="urn:rosettanet:specification:domain:Logistics:Incoterms:xsd:codelist:01.03"
				xmlns:dit="urn:rosettanet:specification:domain:Procurement:InventoryType:xsd:codelist:01.03"
				xmlns:dl="urn:rosettanet:specification:domain:Logistics:xsd:schema:02.22"
				xmlns:dldr="urn:rosettanet:specification:domain:Logistics:LotDiscrepancyReason:xsd:codelist:01.03"
				xmlns:dlit="urn:rosettanet:specification:domain:Logistics:InstructionType:xsd:codelist:01.00"
				xmlns:dlqc="urn:rosettanet:specification:domain:Manufacturing:LotQuantityClassification:xsd:codelist:01.04"
				xmlns:dlt="urn:rosettanet:specification:domain:Manufacturing:LotType:xsd:codelist:01.04"
				xmlns:dltcc="urn:rosettanet:specification:domain:Procurement:LeadTimeClassificationCode:xsd:codelist:01.03"
				xmlns:dm="urn:rosettanet:specification:domain:Manufacturing:xsd:schema:02.27"
				xmlns:dmct="urn:rosettanet:specification:domain:Manufacturing:ComponentType:xsd:codelist:01.02"
				xmlns:dmrcc="urn:rosettanet:specification:domain:Manufacturing:ReplacementCompatibilityCode:xsd:codelist:01.01"
				xmlns:dms="urn:rosettanet:specification:domain:Manufacturing:MarkSide:xsd:codelist:01.03"
				xmlns:dmt="urn:rosettanet:specification:domain:Manufacturing:MarkType:xsd:codelist:01.03"
				xmlns:dnecc="urn:rosettanet:specification:domain:Logistics:NationalExportControlClassification:xsd:codelist:01.03"
				xmlns:dp="urn:rosettanet:specification:domain:Procurement:xsd:schema:02.27"
				xmlns:dpc="urn:rosettanet:specification:domain:Procurement:PaymentCondition:xsd:codelist:01.03"
				xmlns:dpcm="urn:rosettanet:specification:domain:Procurement:PurchaseMethod:xsd:codelist:01.03"
				xmlns:dpcmp="urn:rosettanet:specification:domain:Manufacturing:PCMParmType:xsd:codelist:01.04"
				xmlns:dpdt="urn:rosettanet:specification:domain:Procurement:DateType:xsd:codelist:01.00"
				xmlns:dpe="urn:rosettanet:specification:domain:Procurement:Event:xsd:codelist:01.00"
				xmlns:dpiac="urn:rosettanet:specification:domain:Logistics:PortIdentifierAuthorityCode:xsd:codelist:01.03"
				xmlns:dprt="urn:rosettanet:specification:domain:Manufacturing:ProcessType:xsd:codelist:01.03"
				xmlns:dpsr="urn:rosettanet:specification:domain:Procurement:ProductSubstitutionReason:xsd:codelist:01.03"
				xmlns:dptt="urn:rosettanet:specification:domain:Logistics:PortType:xsd:codelist:01.03"
				xmlns:dr="urn:rosettanet:specification:domain:Procurement:Response:xsd:codelist:01.04"
				xmlns:drl="urn:rosettanet:specification:domain:Logistics:RouteLocation:xsd:codelist:01.03"
				xmlns:drlc="urn:rosettanet:specification:domain:Logistics:ReturnLabelCode:xsd:codelist:01.03"
				xmlns:drwt="urn:rosettanet:specification:domain:Manufacturing:RawWaferType:xsd:codelist:01.03"
				xmlns:dscd="urn:rosettanet:specification:domain:Logistics:ShipmentChangeDisposition:xsd:codelist:01.03"
				xmlns:dsd="urn:rosettanet:specification:domain:Logistics:ShippingDocument:xsd:codelist:01.02"
				xmlns:dsdc="urn:rosettanet:specification:domain:Logistics:ShipDateCode:xsd:codelist:01.03"
				xmlns:dsfr="urn:rosettanet:specification:domain:Procurement:SpecialFulfillmentRequest:xsd:codelist:01.03"
				xmlns:dsh="urn:rosettanet:specification:domain:Procurement:SpecialHandling:xsd:codelist:01.04"
				xmlns:dsic="urn:rosettanet:specification:domain:Manufacturing:SpecialInstructionCategory:xsd:codelist:01.04"
				xmlns:dslt="urn:rosettanet:specification:domain:Procurement:SaleType:xsd:codelist:01.04"
				xmlns:dsm="urn:rosettanet:specification:domain:Logistics:ShipmentMode:xsd:codelist:01.05"
				xmlns:dst="urn:rosettanet:specification:domain:Procurement:ShipmentTerms:xsd:codelist:01.03"
				xmlns:dte="urn:rosettanet:specification:domain:Procurement:TransportEvent:xsd:codelist:01.03"
				xmlns:dtec="urn:rosettanet:specification:domain:Procurement:TaxExemptionCode:xsd:codelist:01.03"
				xmlns:dtq="urn:rosettanet:specification:domain:Procurement:TotalQualifier:xsd:codelist:01.03"
				xmlns:dtrt="urn:rosettanet:specification:domain:Logistics:TrackingReferenceType:xsd:codelist:01.06"
				xmlns:dtt="urn:rosettanet:specification:domain:Procurement:TransactionType:xsd:codelist:01.04"
				xmlns:dwbsf="urn:rosettanet:specification:domain:Manufacturing:WaferBackSideFinish:xsd:codelist:01.04"
				xmlns:dwipl="urn:rosettanet:specification:domain:Manufacturing:WorkInProcessLocation:xsd:codelist:01.03"
				xmlns:dwp="urn:rosettanet:specification:domain:Manufacturing:WaferPassivation:xsd:codelist:01.04"
				xmlns:dwqr="urn:rosettanet:specification:domain:Manufacturing:WaferQualityRating:xsd:codelist:01.03"
				xmlns:rfob="urn:rosettanet:specification:domain:Shared:FreeOnBoard:xsd:codelist:01.01"
				xmlns:ri="urn:rosettanet:specification:domain:Shared:Interval:xsd:codelist:01.01"
				xmlns:rict="urn:rosettanet:specification:domain:Shared:InvoiceChargeType:xsd:codelist:01.02"
				xmlns:rmat="urn:rosettanet:specification:domain:Shared:MonetaryAmountType:xsd:codelist:01.01"
				xmlns:rpkt="urn:rosettanet:specification:domain:Shared:PackageType:xsd:codelist:01.01"
				xmlns:rpktc="urn:rosettanet:specification:domain:Shared:PackageTypeCode:xsd:codelist:01.01"
				xmlns:rpm="urn:rosettanet:specification:domain:Shared:PaymentMethod:xsd:codelist:01.02"
				xmlns:rptc="urn:rosettanet:specification:domain:Shared:PricingTypeCode:xsd:codelist:01.04"
				xmlns:rssl="urn:rosettanet:specification:domain:Shared:ShippingServiceLevel:xsd:codelist:01.01"
				xmlns:sft="urn:rosettanet:specification:system:TPIRFileType:xsd:codelist:01.01"
				xmlns:sha="urn:rosettanet:specification:domain:Shared:xsd:schema:01.17"
				xmlns:ssdh="urn:rosettanet:specification:system:StandardDocumentHeader:xsd:schema:01.23"
				xmlns:st="http://www.ascc.net/xml/schematron"
				xmlns:uat="urn:rosettanet:specification:universal:AbstractType:xsd:schema:01.02"
				xmlns:uc="urn:rosettanet:specification:universal:Country:xsd:codelist:01.02"
				xmlns:uci="urn:rosettanet:specification:universal:ContactInformation:xsd:schema:01.04"
				xmlns:ucr="urn:rosettanet:specification:universal:Currency:xsd:codelist:01.03"
				xmlns:ucs="urn:rosettanet:specification:universal:CountrySubdivision:xsd:codelist:01.02"
				xmlns:ud="urn:rosettanet:specification:universal:Dates:xsd:schema:01.03"
				xmlns:udc="urn:rosettanet:specification:universal:Document:xsd:schema:01.12"
				xmlns:udct="urn:rosettanet:specification:universal:DocumentType:xsd:codelist:01.13"
				xmlns:udt="urn:rosettanet:specification:universal:DataType:xsd:schema:01.04"
				xmlns:ul="urn:rosettanet:specification:universal:Language:xsd:codelist:01.02"
				xmlns:ulc="urn:rosettanet:specification:universal:Locations:xsd:schema:01.04"
				xmlns:ume="urn:rosettanet:specification:universal:MonetaryExpression:xsd:schema:01.06"
				xmlns:umtq="urn:rosettanet:specification:universal:MimeTypeQualifier:xsd:codelist:01.02"
				xmlns:upd="urn:rosettanet:specification:universal:PhysicalDimension:xsd:schema:01.07"
				xmlns:updi="urn:rosettanet:specification:universal:ProductIdentification:xsd:schema:01.04"
				xmlns:upi="urn:rosettanet:specification:universal:PartnerIdentification:xsd:schema:01.16"
				xmlns:upri="urn:rosettanet:specification:universal:ProcessRoleIdentifier:xsd:codelist:01.11"
				xmlns:urss="urn:rosettanet:specification:system:xml:1.0"
				xmlns:utt="urn:rosettanet:specification:universal:TaxType:xsd:codelist:01.02"
				xmlns:uuom="urn:rosettanet:specification:universal:UnitOfMeasure:xsd:codelist:01.04"
				xmlns:uwt="urn:rosettanet:specification:universal:WeightType:xsd:codelist:01.02"
				xmlns:xs="http://www.w3.org/2001/XMLSchema"
				xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
				xsi:schemaLocation="urn:rosettanet:specification:interchange:AdvanceShipmentNotification:xsd:schema:02.04....XMLInterchangeAdvanceShipmentNotification_02_04.xsd">
			  <AdvanceShipment>
				<PurchasedBy>
				  <upi:SpecifiedFullPartner/>
				</PurchasedBy>
				<ShipFrom>
				  <upi:SpecifiedFullPartner>
					<ulc:Location>
					  <ulc:AlternativeIdentifier>
						<ulc:Authority>Shipping Site Name</ulc:Authority>     
						<ulc:Identifier>' + C.SHIPPING_SITE_NAME + '</ulc:Identifier>
					  </ulc:AlternativeIdentifier>
					</ulc:Location>
				  </upi:SpecifiedFullPartner>
				</ShipFrom>
				<Shipment>
				  <CarrierCode>' + A.CARRIER_CODE + '</CarrierCode>
				  <Identifier>' + A.TRIP_ID + '</Identifier>
				  <NumberOfShippingContainers>' + A.SHIPPING_CONTAINERS + '</NumberOfShippingContainers>
				  <dl:ShipmentDate>
					<dl:ShipDate>' + REPLACE(A.SHIP_DATE, ' ', 'T') + C.SHIP_DATE_WITH_TIMEZONE + '</dl:ShipDate>
					<dsdc:ShipDateCode identifier="ShipDateCode" codeListVersion="01.01" agency="RosettaNet">' + A.SHIPDATE_CODE + '</dsdc:ShipDateCode>
				  </dl:ShipmentDate>
				  <ShippingContainer>
					<Identifier>' + A.DELIVERY_ID + '</Identifier>
					<ShippingContainerItem>
					  <udc:BusinessDocumentReference>
						<udct:DocumentType identifier="DocumentType" codeListVersion="01.12" agency="RosettaNet">PUO</udct:DocumentType>
						<udc:Identifier>' + A.PO_NUMBER + '</udc:Identifier>
						<udc:Line>' + A.LINE_NUMBER + '</udc:Line>
						' + @ORDER_RELEASE_NUMBER + '
					  </udc:BusinessDocumentReference>
					  <DocumentSubLineLotShipReference>
						<udct:DocumentType>' + C.DOCUMENTTYPE_1 + '</udct:DocumentType>
						<udc:Identifier>' + C.IDENTIFIER_1 + '</udc:Identifier>
						<ShippedLotQuantity>' + B.SHIPPED_LOT_QUANTITY + '</ShippedLotQuantity>
					  </DocumentSubLineLotShipReference>
					  <DocumentSubLineLotShipReference>
						<udct:DocumentType>' + C.DOCUMENTTYPE_2 + '</udct:DocumentType>
						<udc:Identifier>' + C.IDENTIFIER_2 + '</udc:Identifier>
						<ShippedLotQuantity>' + B.SHIPPED_LOT_QUANTITY + '</ShippedLotQuantity>
					  </DocumentSubLineLotShipReference>
					  <HazardousMaterial>' + @HAZARDOUS_MATERIAL + '</HazardousMaterial>
					  <updi:ProductIdentification>
						<ulc:AlternativeIdentifier>
						  <ulc:Authority>INVENTORY_ITEM_NUMBER</ulc:Authority>
						  <ulc:Identifier>' + @INVENTORY_ITEM_NUMBER + '</ulc:Identifier>
						</ulc:AlternativeIdentifier>
					  </updi:ProductIdentification>
					  <ShippedQuantity>' + @Shipped_Quantity + '</ShippedQuantity>
					  <uuom:UnitOfMeasure identifier="UnitOfMeasure" codeListVersion="01.03" agency="RosettaNet">' + @UOM + '</uuom:UnitOfMeasure>
					</ShippingContainerItem>
					' + @SubContainer + '
					<dl:TrackingReference>
					  <dl:ShipmentTrackingIdentifier>' + @TRACKING_NUMBER + '</dl:ShipmentTrackingIdentifier>
					  <dtrt:TrackingReferenceType identifier="TrackingReferenceType" codeListVersion="01.05" agency="RosettaNet">FTR</dtrt:TrackingReferenceType>
					</dl:TrackingReference>
					<dl:TrackingReference>
					  <dl:ShipmentTrackingIdentifier>' + A.SHIP_VIA + '</dl:ShipmentTrackingIdentifier>
					  <dtrt:TrackingReferenceType identifier="TrackingReferenceType" codeListVersion="01.05" agency="RosettaNet">CRN</dtrt:TrackingReferenceType>
					</dl:TrackingReference>
				  </ShippingContainer>
				  <rssl:ShippingServiceLevel identifier="ShippingServiceLevel" codeListVersion="01.00" agency="RosettaNet">' + A.SERVICE_LEVEL + '</rssl:ShippingServiceLevel>
				  <ShipTo>
					<upi:SpecifiedFullPartner/>
				  </ShipTo>
				  <TransportedBy>
					<upi:SpecifiedFullPartner>
					  <ulc:Location>
						<udt:DUNS>' + A.SENDER_DUNS_NUMBER + '</udt:DUNS>
					  </ulc:Location>
					</upi:SpecifiedFullPartner>
				  </TransportedBy>
				</Shipment>
				<SoldBy>
				  <upi:SpecifiedFullPartner/>
				</SoldBy>
			  </AdvanceShipment>
			  <ssdh:DocumentHeader>
				<ssdh:DocumentInformation>
				  <ssdh:Creation>' + REPLACE(A.TRANSMISSION_DATE, ' ', 'T') + C.SHIP_DATE_WITH_TIMEZONE + '</ssdh:Creation>
				  <ssdh:DocumentIdentification>
					<ssdh:Identifier>' + A.MESSAGE_ID + '</ssdh:Identifier>
					<ssdh:Type>3B2SC-INT-INB</ssdh:Type>
					<ssdh:StandardDocumentIdentification>
					  <ssdh:Standard>RosettaNet</ssdh:Standard>
					  <ssdh:Version>PIP3B2v11.02.00</ssdh:Version>
					</ssdh:StandardDocumentIdentification>
				  </ssdh:DocumentIdentification>
				</ssdh:DocumentInformation>
				<ssdh:Receiver>
				  <ssdh:BusinessServiceInformation>
					<ssdh:ActionName>Request</ssdh:ActionName>
					<ssdh:ProcessIdentifier>3B2 ShipConfirm Interplant Inbound</ssdh:ProcessIdentifier>
					<ssdh:ServiceName>Request 3B2 SC INTPLANT Inbound</ssdh:ServiceName>
				  </ssdh:BusinessServiceInformation>
				  <upi:PartnerIdentification>
					<udt:DUNS>' + A.RECEIVER_DUNS_NUMBER + '</udt:DUNS>
				  </upi:PartnerIdentification>
				</ssdh:Receiver>
				<ssdh:Sender>
				  <ssdh:BusinessServiceInformation>
					<ssdh:ActionName>Request</ssdh:ActionName>
					<ssdh:ProcessIdentifier>3B2 ShipConfirm Interplant Inbound</ssdh:ProcessIdentifier>
					<ssdh:ServiceName>Request 3B2SC INTPLANT Inbound</ssdh:ServiceName>
				  </ssdh:BusinessServiceInformation>
				  <upi:PartnerIdentification>
					<udt:DUNS>' + A.SENDER_DUNS_NUMBER + '</udt:DUNS>
				  </upi:PartnerIdentification>
				</ssdh:Sender>
			  </ssdh:DocumentHeader>
			</AdvanceShipmentNotification>
			'
		FROM #OTM_3B2_MAIN A, #OTM_3B2_ITEM B, #OTM_3B2SC_MAPPING C;

		BEGIN TRANSACTION OTM_3B2SC_OUT; 

		UPDATE 
			[dbo].[OTM_3B2_MAIN]
		SET
			SENDFLAG ='S',
			FILE_NAME = 'IISC-' + MESSAGE_ID + '-0-' + SITE_NAME + '-' + SENDER_DUNS_NUMBER + '-' + FORMAT(GETDATE(),'MMddyyHHmmss') + '.xml'
		WHERE MESSAGE_ID = @messageid;

		INSERT INTO [dbo].[TB_B2B_FILE](F_PLANT, F_DOCID, F_TYPE, F_INOUT, F_FILENAME, F_DOC, F_DOCTYPE, F_DOCTIMESTAMP) 
		SELECT 'BTS', MESSAGE_ID, '3B2SC', 'OUT', FILE_NAME, CONVERT(VARBINARY(MAX), @doc), 'XML', FORMAT(GETDATE(), 'yyyy-MM-dd HH:mm:ss') 
		FROM [dbo].[OTM_3B2_MAIN]
		WHERE MESSAGE_ID = @messageid;

		COMMIT TRANSACTION OTM_3B2SC_OUT; 
	END TRY
	BEGIN CATCH
		IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION OTM_3B2SC_OUT; 

		INSERT INTO OMS_SEND_MAIL(SEND_TO, COPY_TO, SUBJECT, BODY_STR, FILENAME) 
		SELECT 'zhi-jie.chen@mail.foxconn.com', NULL, 'Generate 3B2SC file error. MESSAGE_ID: ' + @Messageid + '. [dbo].[OTM_3B2SC_OUT]', ERROR_MESSAGE(), 'System_Alter.txt';

		RETURN;
	END CATCH
END
