USE [EBOMS]
GO
/****** Object:  StoredProcedure [dbo].[OTM_3B18_ALL]    Script Date: 2025/4/9 �W�� 09:25:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Zhi-jie
-- Create date: 2025-01-17
-- Description:	3B18 all processes
-- =============================================
ALTER PROCEDURE [dbo].[OTM_3B18_ALL] 
AS
BEGIN
	--Parse 3B18
	DECLARE @TotalRows AS INT, @CurrentRowID AS INT = 1, --Loop
			@F_DOCID AS VARCHAR(50), --3B18
			@MESSAGE_ID AS VARCHAR(30); --3B18FA
	
	IF OBJECT_ID('tempdb..#DOCID_LIST') IS NOT NULL
		DROP TABLE #DOCID_LIST;

	SELECT 
		ROW_NUMBER() OVER(ORDER BY F_DOCID) AS ROW_ID, 
		F_DOCID
	INTO #DOCID_LIST
	FROM [dbo].[TB_B2B_FILE] WHERE F_TYPE = '3B18' AND F_FILENAME LIKE 'OINT3B18%' AND F_STATUS = 0; 

	SELECT @TotalRows = COUNT(*) FROM #DOCID_LIST; 

	WHILE @CurrentRowID <= @TotalRows
	BEGIN
		SELECT @F_DOCID = F_DOCID FROM #DOCID_LIST WHERE ROW_ID = @CurrentRowID; 

		EXEC [dbo].[OTM_3B18_PARSE] @DOCID = @F_DOCID; 

		SET @CurrentRowID = @CurrentRowID + 1; 
	END

	--Generate 3B18 FA	
	IF OBJECT_ID('tempdb..#MESSAGEID_LIST') IS NOT NULL
		DROP TABLE #MESSAGEID_LIST; 

	SELECT 
		ROW_NUMBER() OVER(ORDER BY MESSAGE_ID) AS ROW_ID, 
		MESSAGE_ID 
	INTO #MESSAGEID_LIST 
	FROM [dbo].[OTM_FA_TO_CISCO] WHERE SENDFLAG = 'N'; 
	
	SET @CurrentRowID = 1; 
	SELECT @TotalRows = COUNT(*) FROM #MESSAGEID_LIST; 

	WHILE @CurrentRowID <= @TotalRows
	BEGIN
		SELECT @MESSAGE_ID = MESSAGE_ID FROM #MESSAGEID_LIST WHERE ROW_ID = @CurrentRowID; 

		EXEC [dbo].[OTM_3B18FA_OUT] @Messageid = @MESSAGE_ID; 

		SET @CurrentRowID = @CurrentRowID + 1; 
	END
END
